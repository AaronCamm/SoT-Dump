// Class AthenaInput.NotificationInputId
// Size: 0x38 (Inherited: 0x28)
struct UNotificationInputId : UObject {
	char UnknownData_28[0x10]; // 0x28(0x10)
};

// Class AthenaInput.AnalogInputId
// Size: 0x38 (Inherited: 0x28)
struct UAnalogInputId : UObject {
	char UnknownData_28[0x10]; // 0x28(0x10)
};

// Class AthenaInput.OpenEscapeMenuNotificationInputId
// Size: 0x38 (Inherited: 0x38)
struct UOpenEscapeMenuNotificationInputId : UNotificationInputId {
};

// Class AthenaInput.ReceivesInputInterface
// Size: 0x28 (Inherited: 0x28)
struct UReceivesInputInterface : UInterface {
};

// Class AthenaInput.NPCReceivesInputIndicatorComponent
// Size: 0xd0 (Inherited: 0xc8)
struct UNPCReceivesInputIndicatorComponent : UActorComponent {
	char UnknownData_C8[0x8]; // 0xc8(0x08)
};

