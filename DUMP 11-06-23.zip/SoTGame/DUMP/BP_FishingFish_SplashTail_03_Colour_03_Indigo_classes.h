// BlueprintGeneratedClass BP_FishingFish_SplashTail_03_Colour_03_Indigo.BP_FishingFish_SplashTail_03_Colour_03_Indigo_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_SplashTail_03_Colour_03_Indigo_C : ABP_FishingFish_SplashTail_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_SplashTail_03_Colour_03_Indigo.BP_FishingFish_SplashTail_03_Colour_03_Indigo_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

