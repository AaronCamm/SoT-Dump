// BlueprintGeneratedClass BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C
// Size: 0x1f8 (Inherited: 0x138)
struct UBP_GenericVoyageHintPromptCoordinator_Base_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool PromptEvaluated; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct UClass* LocalPromptAccessKey; // 0x148(0x08)
	struct FObjectMessagingHandle OnVoyageHintPopupRequestedHandle; // 0x150(0x58)
	bool PopupRequestReceived; // 0x1a8(0x01)
	char UnknownData_1A9[0x7]; // 0x1a9(0x07)
	struct FRequestContextualVoyageHintPopupEvent CachedEvent; // 0x1b0(0x18)
	char HintType; // 0x1c8(0x01)
	char UnknownData_1C9[0x7]; // 0x1c9(0x07)
	struct UVoyageTypeTutorialPrioritisedPromptsDataAsset* CachedPrioritisedPromptsDataAsset; // 0x1d0(0x08)
	struct UVoyageTypeTutorialPrioritisedPromptsDataAsset* VoyageTypeTutorialPrioritisedPromptsDataAsset; // 0x1d8(0x20)

	void InitializePromptInfo(struct UClass* InAccessKeyType, char InHintType); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.InitializePromptInfo // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnLoaded_B52CCB28421C9CD4FB298DA0CBAAB617(struct UObject* Loaded); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.OnLoaded_B52CCB28421C9CD4FB298DA0CBAAB617 // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnVoyageHintPopupRequestedEvent(struct FRequestContextualVoyageHintPopupEvent Ev); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.OnVoyageHintPopupRequestedEvent // HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_GenericVoyageHintPromptCoordinator_Base(int32_t EntryPoint); // Function BP_GenericVoyageHintPromptCoordinator_Base.BP_GenericVoyageHintPromptCoordinator_Base_C.ExecuteUbergraph_BP_GenericVoyageHintPromptCoordinator_Base // HasDefaults // @ game+0x18275d0
};

