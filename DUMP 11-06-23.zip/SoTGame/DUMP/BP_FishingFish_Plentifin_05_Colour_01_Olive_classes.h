// BlueprintGeneratedClass BP_FishingFish_Plentifin_05_Colour_01_Olive.BP_FishingFish_Plentifin_05_Colour_01_Olive_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Plentifin_05_Colour_01_Olive_C : ABP_FishingFish_Plentifin_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_Plentifin_05_Colour_01_Olive.BP_FishingFish_Plentifin_05_Colour_01_Olive_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

