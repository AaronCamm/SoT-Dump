// BlueprintGeneratedClass BP_FlintlockPistol.BP_FlintlockPistol_C
// Size: 0xb28 (Inherited: 0xaf0)
struct ABP_FlintlockPistol_C : AProjectileWeapon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xaf0(0x08)
	struct UPostProcessComponent* PostProcess; // 0xaf8(0x08)
	char sfx relationship; // 0xb00(0x01)
	char UnknownData_B01[0x7]; // 0xb01(0x07)
	struct UMaterialInstanceDynamic* DynamicMaterial; // 0xb08(0x08)
	struct UObject* ThirdPerson_VFX_AI; // 0xb10(0x08)
	struct UWwiseEvent* Flintlock3rdPersonSFX; // 0xb18(0x08)
	struct UWwiseEvent* FlintLockFirstPersonSFX; // 0xb20(0x08)

	void SetScopeEffectOn(bool IsOn); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.SetScopeEffectOn // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void determine sfx relationship(char Relationship); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.determine sfx relationship // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void DoFireEffect(); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.DoFireEffect // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnWeaponFired(); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.OnWeaponFired // Event|Protected|BlueprintEvent // @ game+0x18275d0
	void RadialBlurOn(); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.RadialBlurOn // Event|Protected|BlueprintEvent // @ game+0x18275d0
	void RadialBlurOff(); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.RadialBlurOff // Event|Protected|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_FlintlockPistol(int32_t EntryPoint); // Function BP_FlintlockPistol.BP_FlintlockPistol_C.ExecuteUbergraph_BP_FlintlockPistol //  // @ game+0x18275d0
};

