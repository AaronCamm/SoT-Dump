// BlueprintGeneratedClass BP_ArmoryChestInteraction.BP_ArmoryChestInteraction_C
// Size: 0x4b8 (Inherited: 0x4b0)
struct ABP_ArmoryChestInteraction_C : AArmoryChestInteraction {
	struct USceneComponent* DefaultSceneRoot; // 0x4b0(0x08)

	void UserConstructionScript(); // Function BP_ArmoryChestInteraction.BP_ArmoryChestInteraction_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

