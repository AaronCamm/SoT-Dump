// BlueprintGeneratedClass BP_ClothingChestInteraction.BP_ClothingChestInteraction_C
// Size: 0x700 (Inherited: 0x6f8)
struct ABP_ClothingChestInteraction_C : AClothingChestInteraction {
	struct USceneComponent* DefaultSceneRoot; // 0x6f8(0x08)

	void UserConstructionScript(); // Function BP_ClothingChestInteraction.BP_ClothingChestInteraction_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

