// BlueprintGeneratedClass BP_HumanoidActionStateCreatorDefinition.BP_HumanoidActionStateCreatorDefinition_C
// Size: 0xa68 (Inherited: 0xa60)
struct ABP_HumanoidActionStateCreatorDefinition_C : AHumanoidActionStateCreatorDefinition {
	struct USceneComponent* DefaultSceneRoot; // 0xa60(0x08)

	void UserConstructionScript(); // Function BP_HumanoidActionStateCreatorDefinition.BP_HumanoidActionStateCreatorDefinition_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

