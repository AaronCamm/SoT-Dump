// BlueprintGeneratedClass BP_Bell.BP_Bell_C
// Size: 0x578 (Inherited: 0x570)
struct ABP_Bell_C : ABell {
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x570(0x08)

	void UserConstructionScript(); // Function BP_Bell.BP_Bell_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

