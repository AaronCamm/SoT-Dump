// BlueprintGeneratedClass BP_CaptainsLog_Interactable_Proxy.BP_CaptainsLog_Interactable_Proxy_C
// Size: 0x780 (Inherited: 0x778)
struct ABP_CaptainsLog_Interactable_Proxy_C : ACaptainsLogbookInteractableProxy {
	struct USceneComponent* PlayerPosition; // 0x778(0x08)

	struct FText GetObjectDisplayName(); // Function BP_CaptainsLog_Interactable_Proxy.BP_CaptainsLog_Interactable_Proxy_C.GetObjectDisplayName // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x18275d0
	struct FDockableInfo GetDockableInfo(); // Function BP_CaptainsLog_Interactable_Proxy.BP_CaptainsLog_Interactable_Proxy_C.GetDockableInfo // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_CaptainsLog_Interactable_Proxy.BP_CaptainsLog_Interactable_Proxy_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

