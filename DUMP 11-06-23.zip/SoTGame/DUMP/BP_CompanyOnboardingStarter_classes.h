// BlueprintGeneratedClass BP_CompanyOnboardingStarter.BP_CompanyOnboardingStarter_C
// Size: 0x60 (Inherited: 0x60)
struct UBP_CompanyOnboardingStarter_C : UCompanyOnboardingStarter {

	bool HasPrerequisites(); // Function BP_CompanyOnboardingStarter.BP_CompanyOnboardingStarter_C.HasPrerequisites // Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

