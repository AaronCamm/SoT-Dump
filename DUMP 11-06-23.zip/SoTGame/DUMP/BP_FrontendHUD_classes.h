// BlueprintGeneratedClass BP_FrontendHUD.BP_FrontendHUD_C
// Size: 0x660 (Inherited: 0x658)
struct ABP_FrontendHUD_C : AFrontendHUD {
	struct USceneComponent* DefaultSceneRoot; // 0x658(0x08)

	void UserConstructionScript(); // Function BP_FrontendHUD.BP_FrontendHUD_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

