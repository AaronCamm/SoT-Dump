// BlueprintGeneratedClass BP_Rudder.BP_Rudder_C
// Size: 0x450 (Inherited: 0x440)
struct ABP_Rudder_C : ARudder {
	struct UStaticMeshComponent* StaticMesh; // 0x440(0x08)
	struct USceneComponent* Root; // 0x448(0x08)

	void UserConstructionScript(); // Function BP_Rudder.BP_Rudder_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

