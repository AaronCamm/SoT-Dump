// BlueprintGeneratedClass BP_Projectile_SirenTrident.BP_Projectile_SirenTrident_C
// Size: 0x830 (Inherited: 0x830)
struct ABP_Projectile_SirenTrident_C : ABP_AIProjectile_SirenTrident_C {

	void UserConstructionScript(); // Function BP_Projectile_SirenTrident.BP_Projectile_SirenTrident_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

