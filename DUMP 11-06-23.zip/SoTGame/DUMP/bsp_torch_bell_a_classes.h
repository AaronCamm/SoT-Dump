// BlueprintGeneratedClass bsp_torch_bell_a.bsp_torch_bell_a_C
// Size: 0x3e8 (Inherited: 0x3d8)
struct Absp_torch_bell_a_C : AStaticMeshActor {
	struct UPointLightComponent* PointLight; // 0x3d8(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x3e0(0x08)

	void UserConstructionScript(); // Function bsp_torch_bell_a.bsp_torch_bell_a_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

