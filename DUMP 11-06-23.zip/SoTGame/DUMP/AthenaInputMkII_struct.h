// Enum AthenaInputMkII.ELeftStickScalarReason
enum class ELeftStickScalarReason : uint8_t {
	Limping,
	Pacing,
	NumReasons,
	ELeftStickScalarReason_MAX,
};

