// BlueprintGeneratedClass BP_PetChestInteraction.BP_PetChestInteraction_C
// Size: 0x6c8 (Inherited: 0x6c0)
struct ABP_PetChestInteraction_C : APetChestInteraction {
	struct USceneComponent* DefaultSceneRoot; // 0x6c0(0x08)

	void UserConstructionScript(); // Function BP_PetChestInteraction.BP_PetChestInteraction_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

