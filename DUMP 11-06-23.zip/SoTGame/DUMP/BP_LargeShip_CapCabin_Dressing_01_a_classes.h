// BlueprintGeneratedClass BP_LargeShip_CapCabin_Dressing_01_a.BP_LargeShip_CapCabin_Dressing_01_a_C
// Size: 0x400 (Inherited: 0x3d8)
struct ABP_LargeShip_CapCabin_Dressing_01_a_C : ATrinketReplacementActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d8(0x08)
	struct UStaticMeshComponent* cap_wooden_plaque_01_a; // 0x3e0(0x08)
	struct UStaticMeshComponent* cap_model_01_a; // 0x3e8(0x08)
	struct UStaticMeshComponent* cap_shark_jaws_01_a; // 0x3f0(0x08)
	struct UMergedStaticMeshComponent* MergedStaticMesh; // 0x3f8(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_CapCabin_Dressing_01_a.BP_LargeShip_CapCabin_Dressing_01_a_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_LargeShip_CapCabin_Dressing_01_a.BP_LargeShip_CapCabin_Dressing_01_a_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_LargeShip_CapCabin_Dressing_01_a(int32_t EntryPoint); // Function BP_LargeShip_CapCabin_Dressing_01_a.BP_LargeShip_CapCabin_Dressing_01_a_C.ExecuteUbergraph_BP_LargeShip_CapCabin_Dressing_01_a //  // @ game+0x18275d0
};

