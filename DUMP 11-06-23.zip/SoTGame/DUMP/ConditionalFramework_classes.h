// Class ConditionalFramework.ConditionRootAsset
// Size: 0x48 (Inherited: 0x28)
struct UConditionRootAsset : UDataAsset {
	struct FConditionInstance ConditionRoot; // 0x28(0x20)
};

