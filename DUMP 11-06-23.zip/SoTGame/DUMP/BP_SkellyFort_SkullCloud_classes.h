// BlueprintGeneratedClass BP_SkellyFort_SkullCloud.BP_SkellyFort_SkullCloud_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct ABP_SkellyFort_SkullCloud_C : ABP_RotatableSignalCloud_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b8(0x08)

	void UserConstructionScript(); // Function BP_SkellyFort_SkullCloud.BP_SkellyFort_SkullCloud_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_SkellyFort_SkullCloud.BP_SkellyFort_SkullCloud_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_SkellyFort_SkullCloud(int32_t EntryPoint); // Function BP_SkellyFort_SkullCloud.BP_SkellyFort_SkullCloud_C.ExecuteUbergraph_BP_SkellyFort_SkullCloud //  // @ game+0x18275d0
};

