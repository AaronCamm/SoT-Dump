// AnimBlueprintGeneratedClass BP_Anim_HurdyGurdy.BP_Anim_HurdyGurdy_C
// Size: 0x710 (Inherited: 0x660)
struct UBP_Anim_HurdyGurdy_C : UWieldableItemAnimationInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x660(0x08)
	struct FAnimNode_Root AnimGraphNode_Root_B3965DEB4C5D27BA9A2E829C0890A4BD; // 0x668(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_575EE4B64923C096D19E05B899C05754; // 0x6b0(0x60)

	void ExecuteUbergraph_BP_Anim_HurdyGurdy(int32_t EntryPoint); // Function BP_Anim_HurdyGurdy.BP_Anim_HurdyGurdy_C.ExecuteUbergraph_BP_Anim_HurdyGurdy //  // @ game+0x18275d0
};

