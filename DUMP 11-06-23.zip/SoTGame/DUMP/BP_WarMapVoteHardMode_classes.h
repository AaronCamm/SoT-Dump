// BlueprintGeneratedClass BP_WarMapVoteHardMode.BP_WarMapVoteHardMode_C
// Size: 0x680 (Inherited: 0x680)
struct ABP_WarMapVoteHardMode_C : ABP_WarMapVoteSingle_C {

	void UserConstructionScript(); // Function BP_WarMapVoteHardMode.BP_WarMapVoteHardMode_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

