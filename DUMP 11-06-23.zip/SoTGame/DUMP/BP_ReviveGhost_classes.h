// BlueprintGeneratedClass BP_ReviveGhost.BP_ReviveGhost_C
// Size: 0x650 (Inherited: 0x628)
struct ABP_ReviveGhost_C : AReviveGhost {
	struct UAnimNotifyWwiseEmitterComponent* AnimNotifyWwiseEmitter; // 0x628(0x08)
	struct UStaticMeshComponent* Cord_Ribbons; // 0x630(0x08)
	struct UStaticMeshComponent* Cord_Outer_02; // 0x638(0x08)
	struct UStaticMeshComponent* Cord_Outer_01; // 0x640(0x08)
	struct UStaticMeshComponent* Cord_Inner; // 0x648(0x08)

	void UserConstructionScript(); // Function BP_ReviveGhost.BP_ReviveGhost_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

