// Class AnimGraphRuntime.AnimSequencerInstance
// Size: 0x5e0 (Inherited: 0x440)
struct UAnimSequencerInstance : UAnimInstance {
	char UnknownData_440[0x1a0]; // 0x440(0x1a0)
};

