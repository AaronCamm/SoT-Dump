// BlueprintGeneratedClass BP_WarMapVoteNormalMode.BP_WarMapVoteNormalMode_C
// Size: 0x680 (Inherited: 0x680)
struct ABP_WarMapVoteNormalMode_C : ABP_WarMapVoteSingle_C {

	void UserConstructionScript(); // Function BP_WarMapVoteNormalMode.BP_WarMapVoteNormalMode_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

