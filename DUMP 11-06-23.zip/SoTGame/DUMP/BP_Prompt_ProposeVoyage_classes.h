// BlueprintGeneratedClass BP_Prompt_ProposeVoyage.BP_Prompt_ProposeVoyage_C
// Size: 0x210 (Inherited: 0x138)
struct UBP_Prompt_ProposeVoyage_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_OfferPurchased; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct FObjectMessagingHandle Handle_OnOfferPurchased; // 0x148(0x58)
	bool State_Complete; // 0x1a0(0x01)
	char UnknownData_1A1[0x7]; // 0x1a1(0x07)
	struct FPrioritisedPromptWithHandle Prompt_ProposeVoyage; // 0x1a8(0x68)

	void PostInitialize(); // Function BP_Prompt_ProposeVoyage.BP_Prompt_ProposeVoyage_C.PostInitialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Prompt_OfferPurchased(struct FOfferPurchasedEvent Ev); // Function BP_Prompt_ProposeVoyage.BP_Prompt_ProposeVoyage_C.Prompt_OfferPurchased // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_ProposeVoyage.BP_Prompt_ProposeVoyage_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_ProposeVoyage.BP_Prompt_ProposeVoyage_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_ProposeVoyage(int32_t EntryPoint); // Function BP_Prompt_ProposeVoyage.BP_Prompt_ProposeVoyage_C.ExecuteUbergraph_BP_Prompt_ProposeVoyage // HasDefaults // @ game+0x18275d0
};

