// ScriptStruct BumperZone.BumperZoneData
// Size: 0x28 (Inherited: 0x00)
struct FBumperZoneData {
	struct AShipBumperZone* BumperZone; // 0x00(0x08)
	char UnknownData_8[0x20]; // 0x08(0x20)
};

// ScriptStruct BumperZone.CachedShip
// Size: 0x18 (Inherited: 0x00)
struct FCachedShip {
	char UnknownData_0[0x18]; // 0x00(0x18)
};

