// BlueprintGeneratedClass BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C
// Size: 0x222 (Inherited: 0x138)
struct UBP_Prompt_VisitCompanyShop_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_TreasureChestSoldPredictedEvent; // 0x140(0x58)
	struct FPrioritisedPromptWithHandle Prompt_VisitCompanyShop; // 0x198(0x68)
	struct UClass* Company; // 0x200(0x08)
	struct UClass* AccessKey; // 0x208(0x08)
	struct UClass* CompanyRankDesc; // 0x210(0x08)
	float PromptDelayUntilDisplay; // 0x218(0x04)
	float PromptDisplayDuration; // 0x21c(0x04)
	bool IsCorrectCompany; // 0x220(0x01)
	bool PromptInfoSet; // 0x221(0x01)

	void HasAlreadyVisitedCompanyShop(bool HasVistedCompanyShop); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.HasAlreadyVisitedCompanyShop // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void SetCompanyPromptInfo(struct UClass* Company, struct UClass* AccessKey, struct FPrioritisedPromptWithHandle Prompt, struct UClass* CompanyRankDesc); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.SetCompanyPromptInfo // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnTreasureChestSold(struct FTreasureChestSoldClientPredictionEvent Event); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.OnTreasureChestSold // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void TreasureChestSoldPredictedEvent(struct FTreasureChestSoldClientPredictionEvent Event); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.TreasureChestSoldPredictedEvent // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_VisitCompanyShop(int32_t EntryPoint); // Function BP_Prompt_VisitCompanyShop.BP_Prompt_VisitCompanyShop_C.ExecuteUbergraph_BP_Prompt_VisitCompanyShop // HasDefaults // @ game+0x18275d0
};

