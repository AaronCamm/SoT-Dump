// BlueprintGeneratedClass BP_LargeShip_QuestTable.BP_LargeShip_QuestTable_C
// Size: 0x918 (Inherited: 0x8c8)
struct ABP_LargeShip_QuestTable_C : AVoyageTable {
	struct UChildActorComponent* WarMap; // 0x8c8(0x08)
	struct UChildActorComponent* FactionHourglass; // 0x8d0(0x08)
	struct UChildActorComponent* CancelAdventure; // 0x8d8(0x08)
	struct UChildActorComponent* PlayerBuiredItemsMapBundleInteractionPoint; // 0x8e0(0x08)
	struct UChildActorComponent* CancelTale; // 0x8e8(0x08)
	struct UChildActorComponent* CancelVoyage; // 0x8f0(0x08)
	struct UChildActorComponent* VoyageSelectionSlot4; // 0x8f8(0x08)
	struct UChildActorComponent* VoyageSelectionSlot3; // 0x900(0x08)
	struct UChildActorComponent* VoyageSelectionSlot2; // 0x908(0x08)
	struct UChildActorComponent* VoyageSelectionSlot1; // 0x910(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_QuestTable.BP_LargeShip_QuestTable_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

