// BlueprintGeneratedClass BP_SirenTrident_Wieldable.BP_SirenTrident_Wieldable_C
// Size: 0xa30 (Inherited: 0x9f0)
struct ABP_SirenTrident_Wieldable_C : ADoubleActionItemWithAmmo {
	struct UAimSensitivityComponent* AimSensitivity; // 0x9f0(0x08)
	struct UAmmoEffectsComponent* AmmoEffects; // 0x9f8(0x08)
	struct UStaticStashedMeshMemoryConstraintComponent* StaticStashedMeshMemoryConstraint; // 0xa00(0x08)
	struct UAmmoTransferComponent* AmmoTransfer; // 0xa08(0x08)
	struct UItemActionComponent* AimDownSightAction; // 0xa10(0x08)
	struct USirenTridentShotActionComponent* SirenTridentShotAction; // 0xa18(0x08)
	struct ULaunchableAttachPointComponent* LaunchableAttachPoint; // 0xa20(0x08)
	struct UPostProcessComponent* PostProcess; // 0xa28(0x08)

	void UserConstructionScript(); // Function BP_SirenTrident_Wieldable.BP_SirenTrident_Wieldable_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

