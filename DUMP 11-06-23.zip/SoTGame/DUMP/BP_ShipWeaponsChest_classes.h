// BlueprintGeneratedClass BP_ShipWeaponsChest.BP_ShipWeaponsChest_C
// Size: 0x5b8 (Inherited: 0x5a0)
struct ABP_ShipWeaponsChest_C : APossessionsChest {
	struct UCrewLockableComponent* CrewLockableComponent; // 0x5a0(0x08)
	struct UStaticMeshComponent* LockMesh; // 0x5a8(0x08)
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x5b0(0x08)

	void UserConstructionScript(); // Function BP_ShipWeaponsChest.BP_ShipWeaponsChest_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

