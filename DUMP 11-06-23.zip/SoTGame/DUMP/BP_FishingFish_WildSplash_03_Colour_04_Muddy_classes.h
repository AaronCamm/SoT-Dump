// BlueprintGeneratedClass BP_FishingFish_WildSplash_03_Colour_04_Muddy.BP_FishingFish_WildSplash_03_Colour_04_Muddy_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_WildSplash_03_Colour_04_Muddy_C : ABP_FishingFish_WildSplash_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_WildSplash_03_Colour_04_Muddy.BP_FishingFish_WildSplash_03_Colour_04_Muddy_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

