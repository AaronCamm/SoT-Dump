// BlueprintGeneratedClass BP_Prompt_TavernBoard.BP_Prompt_TavernBoard_C
// Size: 0x271 (Inherited: 0x138)
struct UBP_Prompt_TavernBoard_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle WieldableItemUseEvent; // 0x140(0x58)
	struct UClass* TavernBoardPromptAccessKey; // 0x198(0x08)
	struct FPrioritisedPromptWithHandle Prompt; // 0x1a0(0x68)
	bool InRangeOfTavernBoard; // 0x208(0x01)
	char UnknownData_209[0x7]; // 0x209(0x07)
	struct FObjectMessagingHandle ApproachedTavernBoardHandle; // 0x210(0x58)
	struct FObjectMessagingDispatcherHandle CharacterDispatcher; // 0x268(0x08)
	bool HasShown; // 0x270(0x01)

	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_TavernBoard.BP_Prompt_TavernBoard_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_TavernBoard.BP_Prompt_TavernBoard_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_TavernBoard.BP_Prompt_TavernBoard_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnApproachedTavernBoard(struct FApproachedPlayerGeneratedMapsContainer Event); // Function BP_Prompt_TavernBoard.BP_Prompt_TavernBoard_C.OnApproachedTavernBoard // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_TavernBoard(int32_t EntryPoint); // Function BP_Prompt_TavernBoard.BP_Prompt_TavernBoard_C.ExecuteUbergraph_BP_Prompt_TavernBoard // HasDefaults // @ game+0x18275d0
};

