// BlueprintGeneratedClass BP_FishingFish_SplashTail_05_Colour_05_Seafoam.BP_FishingFish_SplashTail_05_Colour_05_Seafoam_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_SplashTail_05_Colour_05_Seafoam_C : ABP_FishingFish_SplashTail_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_SplashTail_05_Colour_05_Seafoam.BP_FishingFish_SplashTail_05_Colour_05_Seafoam_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

