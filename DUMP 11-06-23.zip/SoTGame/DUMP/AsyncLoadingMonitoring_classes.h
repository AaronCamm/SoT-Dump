// Class AsyncLoadingMonitoring.AsyncLoadingMonitoringServiceInterface
// Size: 0x28 (Inherited: 0x28)
struct UAsyncLoadingMonitoringServiceInterface : UInterface {
};

// Class AsyncLoadingMonitoring.AsyncLoadingMonitoringService
// Size: 0xd0 (Inherited: 0x28)
struct UAsyncLoadingMonitoringService : UObject {
	char UnknownData_28[0xa8]; // 0x28(0xa8)
};

