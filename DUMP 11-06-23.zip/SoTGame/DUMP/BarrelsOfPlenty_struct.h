// ScriptStruct BarrelsOfPlenty.BarrelsOfPlentyDebugLocationEntry
// Size: 0x10 (Inherited: 0x00)
struct FBarrelsOfPlentyDebugLocationEntry {
	struct FVector WorldSpacePosition; // 0x00(0x0c)
	float SinkTime; // 0x0c(0x04)
};

