// BlueprintGeneratedClass BP_AthenaGameState.BP_AthenaGameState_C
// Size: 0xc30 (Inherited: 0xc20)
struct ABP_AthenaGameState_C : AAthenaGameState {
	struct UWorldMarkerRoutingComponent* WorldMarkerRouting; // 0xc20(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0xc28(0x08)

	void UserConstructionScript(); // Function BP_AthenaGameState.BP_AthenaGameState_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

