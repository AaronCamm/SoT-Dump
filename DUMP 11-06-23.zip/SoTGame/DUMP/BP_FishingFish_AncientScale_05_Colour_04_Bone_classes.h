// BlueprintGeneratedClass BP_FishingFish_AncientScale_05_Colour_04_Bone.BP_FishingFish_AncientScale_05_Colour_04_Bone_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_AncientScale_05_Colour_04_Bone_C : ABP_FishingFish_AncientScale_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_AncientScale_05_Colour_04_Bone.BP_FishingFish_AncientScale_05_Colour_04_Bone_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

