// BlueprintGeneratedClass BP_ShipAmmoChest.BP_ShipAmmoChest_C
// Size: 0x4c8 (Inherited: 0x4b0)
struct ABP_ShipAmmoChest_C : ABP_AmmoChest_C {
	struct UStaticMeshComponent* LockMesh; // 0x4b0(0x08)
	struct UCrewLockableComponent* CrewLockableComponent; // 0x4b8(0x08)
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x4c0(0x08)

	void UserConstructionScript(); // Function BP_ShipAmmoChest.BP_ShipAmmoChest_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

