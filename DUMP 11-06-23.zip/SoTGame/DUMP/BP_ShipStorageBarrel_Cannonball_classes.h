// BlueprintGeneratedClass BP_ShipStorageBarrel_Cannonball.BP_ShipStorageBarrel_Cannonball_C
// Size: 0x4e0 (Inherited: 0x4c8)
struct ABP_ShipStorageBarrel_Cannonball_C : AStorageContainer {
	struct UReplenishableComponent* Replenishable; // 0x4c8(0x08)
	struct UShipTelemetrySubjectComponent* ShipTelemetrySubject; // 0x4d0(0x08)
	struct UStorageContainerComponent* StorageContainer; // 0x4d8(0x08)

	void UserConstructionScript(); // Function BP_ShipStorageBarrel_Cannonball.BP_ShipStorageBarrel_Cannonball_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

