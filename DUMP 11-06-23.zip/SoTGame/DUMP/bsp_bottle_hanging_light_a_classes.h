// BlueprintGeneratedClass bsp_bottle_hanging_light_a.bsp_bottle_hanging_light_a_C
// Size: 0x3f8 (Inherited: 0x3d8)
struct Absp_bottle_hanging_light_a_C : AStaticMeshActor {
	struct UStaticMeshComponent* StaticMesh2; // 0x3d8(0x08)
	struct UPointLightComponent* PointLight1; // 0x3e0(0x08)
	struct UPointLightComponent* PointLight; // 0x3e8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x3f0(0x08)

	void UserConstructionScript(); // Function bsp_bottle_hanging_light_a.bsp_bottle_hanging_light_a_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

