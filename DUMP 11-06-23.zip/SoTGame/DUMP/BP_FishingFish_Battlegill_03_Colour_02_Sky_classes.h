// BlueprintGeneratedClass BP_FishingFish_Battlegill_03_Colour_02_Sky.BP_FishingFish_Battlegill_03_Colour_02_Sky_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Battlegill_03_Colour_02_Sky_C : ABP_FishingFish_Battlegill_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_Battlegill_03_Colour_02_Sky.BP_FishingFish_Battlegill_03_Colour_02_Sky_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

