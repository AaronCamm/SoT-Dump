// BlueprintGeneratedClass BP_FishingFish_Battlegill_05.BP_FishingFish_Battlegill_05_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Battlegill_05_C : ABP_FishingFish_Battlegill_Base_C {

	void UserConstructionScript(); // Function BP_FishingFish_Battlegill_05.BP_FishingFish_Battlegill_05_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

