// ScriptStruct AthenaStatusResponse.ScalarParamInfo
// Size: 0x10 (Inherited: 0x00)
struct FScalarParamInfo {
	struct FName ParamName; // 0x00(0x08)
	bool UseWorldTime; // 0x08(0x01)
	char UnknownData_9[0x3]; // 0x09(0x03)
	float NewScalarValue; // 0x0c(0x04)
};

