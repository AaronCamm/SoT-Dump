// BlueprintGeneratedClass BP_FishingFish_Plentifin_03_Colour_04_Bonedust.BP_FishingFish_Plentifin_03_Colour_04_Bonedust_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Plentifin_03_Colour_04_Bonedust_C : ABP_FishingFish_Plentifin_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_Plentifin_03_Colour_04_Bonedust.BP_FishingFish_Plentifin_03_Colour_04_Bonedust_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

