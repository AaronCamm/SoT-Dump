// BlueprintGeneratedClass BP_Bed_Large.BP_Bed_Large_C
// Size: 0x3e0 (Inherited: 0x3d8)
struct ABP_Bed_Large_C : ABP_Bed_C {
	struct UStaticMeshComponent* DrapesMeshComponent; // 0x3d8(0x08)

	struct UStaticMeshComponent* GetDrapesMeshComponent(); // Function BP_Bed_Large.BP_Bed_Large_C.GetDrapesMeshComponent // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_Bed_Large.BP_Bed_Large_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

