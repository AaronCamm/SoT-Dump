// BlueprintGeneratedClass BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C
// Size: 0x328 (Inherited: 0x138)
struct UBP_Prompt_RepairShipMast_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_ShipMastDamaged; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct FObjectMessagingHandle Handle_OnMastDamaged1; // 0x148(0x58)
	bool State_Complete; // 0x1a0(0x01)
	char UnknownData_1A1[0x7]; // 0x1a1(0x07)
	struct FPrioritisedPromptWithHandle Prompt_RepairShip; // 0x1a8(0x68)
	struct FObjectMessagingHandle Handle_CurrentShipChanged; // 0x210(0x58)
	struct AShip* CurrentShip; // 0x268(0x08)
	struct FObjectMessagingHandle Handle_OnMastDamaged2; // 0x270(0x58)
	struct FObjectMessagingHandle Handle_OnMastDamaged3; // 0x2c8(0x58)
	int32_t NumMastsRegistered; // 0x320(0x04)
	int32_t MastIndex; // 0x324(0x04)

	void UnregisterDamageEventFromCurrentShip(); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.UnregisterDamageEventFromCurrentShip // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterDamageEventWithCurrentShip(); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.RegisterDamageEventWithCurrentShip // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void OnCurrentShipChanged(struct FEventCurrentShipChanged Event); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.OnCurrentShipChanged // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnShipMastDamaged(struct FEventMastDamageLevelChanged Event); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.OnShipMastDamaged // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_RepairShipMast(int32_t EntryPoint); // Function BP_Prompt_RepairShipMast.BP_Prompt_RepairShipMast_C.ExecuteUbergraph_BP_Prompt_RepairShipMast // HasDefaults // @ game+0x18275d0
};

