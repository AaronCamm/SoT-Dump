// Class AthenaServerMigration.AthenaServerMigrationGameAuthorityProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UAthenaServerMigrationGameAuthorityProviderInterface : UInterface {
};

// Class AthenaServerMigration.MigrationProgressInterface
// Size: 0x28 (Inherited: 0x28)
struct UMigrationProgressInterface : UInterface {
};

// Class AthenaServerMigration.MigrationServiceInterface
// Size: 0x28 (Inherited: 0x28)
struct UMigrationServiceInterface : UInterface {
};

// Class AthenaServerMigration.ServerMigrationGatherableActorInterface
// Size: 0x28 (Inherited: 0x28)
struct UServerMigrationGatherableActorInterface : UInterface {
};

// Class AthenaServerMigration.RegisterServerMigrationPointOfInterestComponent
// Size: 0xe8 (Inherited: 0xc8)
struct URegisterServerMigrationPointOfInterestComponent : UActorComponent {
	float MigrationRadius; // 0xc8(0x04)
	char UnknownData_CC[0x1c]; // 0xcc(0x1c)
};

