// BlueprintGeneratedClass BP_PromptActor_EmissarySecuredLootOnShip_OOS.BP_PromptActor_EmissarySecuredLootOnShip_OOS_C
// Size: 0x430 (Inherited: 0x400)
struct ABP_PromptActor_EmissarySecuredLootOnShip_OOS_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_Prompt_EmissarySecuredLootOnShip_C* PromptCoordinator; // 0x408(0x08)
	struct UClass* PromptCounterAccessKey; // 0x410(0x08)
	struct UClass* Company; // 0x418(0x08)
	struct TArray<struct FPrioritisedPromptWithHandle> Prompts; // 0x420(0x10)

	void UserConstructionScript(); // Function BP_PromptActor_EmissarySecuredLootOnShip_OOS.BP_PromptActor_EmissarySecuredLootOnShip_OOS_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_PromptActor_EmissarySecuredLootOnShip_OOS.BP_PromptActor_EmissarySecuredLootOnShip_OOS_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_PromptActor_EmissarySecuredLootOnShip_OOS.BP_PromptActor_EmissarySecuredLootOnShip_OOS_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptActor_EmissarySecuredLootOnShip_OOS(int32_t EntryPoint); // Function BP_PromptActor_EmissarySecuredLootOnShip_OOS.BP_PromptActor_EmissarySecuredLootOnShip_OOS_C.ExecuteUbergraph_BP_PromptActor_EmissarySecuredLootOnShip_OOS //  // @ game+0x18275d0
};

