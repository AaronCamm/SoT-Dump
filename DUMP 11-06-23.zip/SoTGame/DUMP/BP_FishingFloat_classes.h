// BlueprintGeneratedClass BP_FishingFloat.BP_FishingFloat_C
// Size: 0x7f0 (Inherited: 0x7e0)
struct ABP_FishingFloat_C : AFishingFloat {
	struct UFishingFloatNameplateComponent* FishingFloatNameplate; // 0x7e0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x7e8(0x08)

	void UserConstructionScript(); // Function BP_FishingFloat.BP_FishingFloat_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

