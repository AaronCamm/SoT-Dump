// BlueprintGeneratedClass BP_FishItemInfo.BP_FishItemInfo_C
// Size: 0x578 (Inherited: 0x568)
struct ABP_FishItemInfo_C : ARewardableItemInfo {
	struct UDeliverableRedirectionComponent* DeliverableRedirection; // 0x568(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x570(0x08)

	void UserConstructionScript(); // Function BP_FishItemInfo.BP_FishItemInfo_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

