// BlueprintGeneratedClass BP_FishingFish_AncientScale_05_Colour_03_Smoke.BP_FishingFish_AncientScale_05_Colour_03_Smoke_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_AncientScale_05_Colour_03_Smoke_C : ABP_FishingFish_AncientScale_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_AncientScale_05_Colour_03_Smoke.BP_FishingFish_AncientScale_05_Colour_03_Smoke_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

