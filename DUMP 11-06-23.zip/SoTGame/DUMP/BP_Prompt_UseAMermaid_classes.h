// BlueprintGeneratedClass BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C
// Size: 0x2cc (Inherited: 0x138)
struct UBP_Prompt_UseAMermaid_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_IsThereAMermaid; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct FObjectMessagingHandle Handle_OnMermaidActivatedLocally; // 0x148(0x58)
	struct FObjectMessagingHandle Handle_OnMermaidDeactivatedLocally; // 0x1a0(0x58)
	struct FObjectMessagingHandle Handle_OnMermaidUsed; // 0x1f8(0x58)
	bool State_MermaidUsed; // 0x250(0x01)
	char UnknownData_251[0x7]; // 0x251(0x07)
	struct FPrioritisedPromptWithHandle Prompt_UseMermaid; // 0x258(0x68)
	bool State_ShowPrompt; // 0x2c0(0x01)
	char UnknownData_2C1[0x3]; // 0x2c1(0x03)
	float PromptDisplayDuration; // 0x2c4(0x04)
	float PromptHideDuration; // 0x2c8(0x04)

	void ResetState(); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.ResetState // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	struct FPromptEvaluation EvaluatePromptDisplayState(); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.EvaluatePromptDisplayState // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void PostInitialize(); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.PostInitialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Prompt_MermaidActivatedLocally(struct FMermaidActivatedLocally Ev); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.Prompt_MermaidActivatedLocally // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Prompt_MermaidDeactivatedLocally(struct FMermaidDeactivatedLocally Ev); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.Prompt_MermaidDeactivatedLocally // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Prompt_MermaidUsed(struct FMermaidUsedEvent Ev); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.Prompt_MermaidUsed // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_UseAMermaid(int32_t EntryPoint); // Function BP_Prompt_UseAMermaid.BP_Prompt_UseAMermaid_C.ExecuteUbergraph_BP_Prompt_UseAMermaid // HasDefaults // @ game+0x18275d0
};

