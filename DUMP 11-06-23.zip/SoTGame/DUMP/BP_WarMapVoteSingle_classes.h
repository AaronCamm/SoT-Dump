// BlueprintGeneratedClass BP_WarMapVoteSingle.BP_WarMapVoteSingle_C
// Size: 0x680 (Inherited: 0x640)
struct ABP_WarMapVoteSingle_C : AWarMapVoteInteractionActor {
	struct UStaticMeshComponent* VoteIndicator4; // 0x640(0x08)
	struct UStaticMeshComponent* VoteIndicator3; // 0x648(0x08)
	struct UStaticMeshComponent* VoteIndicator2; // 0x650(0x08)
	struct UStaticMeshComponent* VoteIndicator1; // 0x658(0x08)
	struct UVoteAudioComponent* VoteAudio; // 0x660(0x08)
	struct UWarMapInteractionVoteComponent* WarMapInteractionVote; // 0x668(0x08)
	struct UStaticMeshVoteVisualiserComponent* StaticMeshVoteVisualiser; // 0x670(0x08)
	struct UActionRulesComponent* ActionRules; // 0x678(0x08)

	void UserConstructionScript(); // Function BP_WarMapVoteSingle.BP_WarMapVoteSingle_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

