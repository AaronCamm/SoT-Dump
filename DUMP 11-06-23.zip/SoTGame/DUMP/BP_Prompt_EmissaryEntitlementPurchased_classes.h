// BlueprintGeneratedClass BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C
// Size: 0x1e8 (Inherited: 0x138)
struct UBP_Prompt_EmissaryEntitlementPurchased_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_EmissaryEntitlementPurchased; // 0x140(0x58)
	struct FGuid OfferId; // 0x198(0x10)
	struct FGuid ExpectedOfferId; // 0x1a8(0x10)
	struct TArray<struct FPrioritisedPromptWithHandle> Prompts; // 0x1b8(0x10)
	bool PromptSurfacedThisSession; // 0x1c8(0x01)
	char UnknownData_1C9[0x7]; // 0x1c9(0x07)
	struct UClass* PromptAccessKey; // 0x1d0(0x08)
	int32_t PromptIndex; // 0x1d8(0x04)
	int32_t NumberOfPrompts; // 0x1dc(0x04)
	float InitialDelay; // 0x1e0(0x04)
	float ShowPromptDuration; // 0x1e4(0x04)

	void OnEmissaryEntitlementPurchasedFunc(struct FEmissaryEntitlementPurchasedEvent NewParam); // Function BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C.OnEmissaryEntitlementPurchasedFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void EmissaryEntitlementPurchased(struct FEmissaryEntitlementPurchasedEvent NewParam); // Function BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C.EmissaryEntitlementPurchased // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_EmissaryEntitlementPurchased(int32_t EntryPoint); // Function BP_Prompt_EmissaryEntitlementPurchased.BP_Prompt_EmissaryEntitlementPurchased_C.ExecuteUbergraph_BP_Prompt_EmissaryEntitlementPurchased // HasDefaults // @ game+0x18275d0
};

