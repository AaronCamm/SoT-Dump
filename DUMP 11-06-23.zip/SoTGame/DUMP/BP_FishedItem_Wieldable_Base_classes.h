// BlueprintGeneratedClass BP_FishedItem_Wieldable_Base.BP_FishedItem_Wieldable_Base_C
// Size: 0x800 (Inherited: 0x7e0)
struct ABP_FishedItem_Wieldable_Base_C : AStaticSimpleBootyWieldableItem {
	struct UTrackedOwnerComponent* TrackedOwner; // 0x7e0(0x08)
	struct UWieldableInteractableComponent* WieldableInteractable; // 0x7e8(0x08)
	struct UPickupableComponent* Pickupable; // 0x7f0(0x08)
	struct UUsableWieldableComponent* UsableWieldable; // 0x7f8(0x08)

	void UserConstructionScript(); // Function BP_FishedItem_Wieldable_Base.BP_FishedItem_Wieldable_Base_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

