// BlueprintGeneratedClass BP_LargeShip_StandardHull.BP_LargeShip_StandardHull_C
// Size: 0x408 (Inherited: 0x3f0)
struct ABP_LargeShip_StandardHull_C : AHull {
	struct UStaticMeshComponent* Occluder; // 0x3f0(0x08)
	struct UChildActorComponent* Damage; // 0x3f8(0x08)
	struct UChildActorComponent* Art; // 0x400(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_StandardHull.BP_LargeShip_StandardHull_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

