// BlueprintGeneratedClass BP_PromptActor_VisitCompanyShop_GH.BP_PromptActor_VisitCompanyShop_GH_C
// Size: 0x490 (Inherited: 0x400)
struct ABP_PromptActor_VisitCompanyShop_GH_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_Prompt_VisitCompanyShop_C* PromptCoordinator; // 0x408(0x08)
	struct UClass* Company; // 0x410(0x08)
	struct UClass* AccessKey; // 0x418(0x08)
	struct FPrioritisedPromptWithHandle Prompt; // 0x420(0x68)
	struct UClass* CompanyRankDesc; // 0x488(0x08)

	void UserConstructionScript(); // Function BP_PromptActor_VisitCompanyShop_GH.BP_PromptActor_VisitCompanyShop_GH_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_PromptActor_VisitCompanyShop_GH.BP_PromptActor_VisitCompanyShop_GH_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_PromptActor_VisitCompanyShop_GH.BP_PromptActor_VisitCompanyShop_GH_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptActor_VisitCompanyShop_GH(int32_t EntryPoint); // Function BP_PromptActor_VisitCompanyShop_GH.BP_PromptActor_VisitCompanyShop_GH_C.ExecuteUbergraph_BP_PromptActor_VisitCompanyShop_GH //  // @ game+0x18275d0
};

