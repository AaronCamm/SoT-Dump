// Class AIGoals.AlwaysEvaluatesTrueAIGoal
// Size: 0x38 (Inherited: 0x38)
struct UAlwaysEvaluatesTrueAIGoal : UAIGoal {
};

// Class AIGoals.WhileBlackboardKeySetAIGoal
// Size: 0x40 (Inherited: 0x38)
struct UWhileBlackboardKeySetAIGoal : UAIGoal {
	struct FName BlackboardKey; // 0x38(0x08)

	struct TArray<struct FString> GetAllowedBlackboardKeys(); // Function AIGoals.WhileBlackboardKeySetAIGoal.GetAllowedBlackboardKeys // Final|Native|Private|Const // @ game+0x2a2540
};

