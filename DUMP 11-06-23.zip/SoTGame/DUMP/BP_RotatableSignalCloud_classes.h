// BlueprintGeneratedClass BP_RotatableSignalCloud.BP_RotatableSignalCloud_C
// Size: 0x4b8 (Inherited: 0x4a8)
struct ABP_RotatableSignalCloud_C : AGameplayEventSignal_StaticMesh {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a8(0x08)
	struct URotateMeshToLocalPlayerComponent* RotateMeshToLocalPlayer; // 0x4b0(0x08)

	void UserConstructionScript(); // Function BP_RotatableSignalCloud.BP_RotatableSignalCloud_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_RotatableSignalCloud.BP_RotatableSignalCloud_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_RotatableSignalCloud(int32_t EntryPoint); // Function BP_RotatableSignalCloud.BP_RotatableSignalCloud_C.ExecuteUbergraph_BP_RotatableSignalCloud //  // @ game+0x18275d0
};

