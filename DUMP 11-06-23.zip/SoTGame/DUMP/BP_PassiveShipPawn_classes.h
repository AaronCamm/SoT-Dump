// BlueprintGeneratedClass BP_PassiveShipPawn.BP_PassiveShipPawn_C
// Size: 0x480 (Inherited: 0x478)
struct ABP_PassiveShipPawn_C : AShipProxyPawn {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function BP_PassiveShipPawn.BP_PassiveShipPawn_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

