// AnimBlueprintGeneratedClass BP_Seagull_AnimInst.BP_Seagull_AnimInst_C
// Size: 0x4f4 (Inherited: 0x440)
struct UBP_Seagull_AnimInst_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)
	struct FAnimNode_Root AnimGraphNode_Root_3366BBA749515CA7786453A95053A5F8; // 0x448(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_D775EBF64D32A723FA50E08494A680D3; // 0x490(0x60)
	float PlayRate; // 0x4f0(0x04)

	void BlueprintInitializeAnimation(); // Function BP_Seagull_AnimInst.BP_Seagull_AnimInst_C.BlueprintInitializeAnimation // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Seagull_AnimInst(int32_t EntryPoint); // Function BP_Seagull_AnimInst.BP_Seagull_AnimInst_C.ExecuteUbergraph_BP_Seagull_AnimInst //  // @ game+0x18275d0
};

