// BlueprintGeneratedClass BP_PromptActor_TavernBoard.BP_PromptActor_TavernBoard_C
// Size: 0x431 (Inherited: 0x400)
struct ABP_PromptActor_TavernBoard_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_Prompt_TavernBoard_C* PromptCoordinator; // 0x408(0x08)
	struct TArray<struct FVector> TavernBoardLocations; // 0x410(0x10)
	struct TArray<struct UBP_Prompt_TavernBoard_C*> TavernBoardPromptCoordinators; // 0x420(0x10)
	bool HasPromptShown; // 0x430(0x01)

	void OnRep_TavernBoardLocations(); // Function BP_PromptActor_TavernBoard.BP_PromptActor_TavernBoard_C.OnRep_TavernBoardLocations // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_PromptActor_TavernBoard.BP_PromptActor_TavernBoard_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_PromptActor_TavernBoard.BP_PromptActor_TavernBoard_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_PromptActor_TavernBoard.BP_PromptActor_TavernBoard_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptActor_TavernBoard(int32_t EntryPoint); // Function BP_PromptActor_TavernBoard.BP_PromptActor_TavernBoard_C.ExecuteUbergraph_BP_PromptActor_TavernBoard //  // @ game+0x18275d0
};

