// BlueprintGeneratedClass BP_FishingFish_Battlegill_05_Colour_04_Sand.BP_FishingFish_Battlegill_05_Colour_04_Sand_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Battlegill_05_Colour_04_Sand_C : ABP_FishingFish_Battlegill_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_Battlegill_05_Colour_04_Sand.BP_FishingFish_Battlegill_05_Colour_04_Sand_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

