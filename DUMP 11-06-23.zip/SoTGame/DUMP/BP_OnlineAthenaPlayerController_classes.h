// BlueprintGeneratedClass BP_OnlineAthenaPlayerController.BP_OnlineAthenaPlayerController_C
// Size: 0x1818 (Inherited: 0x1810)
struct ABP_OnlineAthenaPlayerController_C : AOnlineAthenaPlayerController {
	struct UBP_Component_Tutorial2019_C* VisitShopkeepersTutorialComponent; // 0x1810(0x08)

	void UserConstructionScript(); // Function BP_OnlineAthenaPlayerController.BP_OnlineAthenaPlayerController_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

