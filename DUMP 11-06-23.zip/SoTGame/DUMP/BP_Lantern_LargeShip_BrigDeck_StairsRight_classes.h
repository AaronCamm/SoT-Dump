// BlueprintGeneratedClass BP_Lantern_LargeShip_BrigDeck_StairsRight.BP_Lantern_LargeShip_BrigDeck_StairsRight_C
// Size: 0x77d (Inherited: 0x77d)
struct ABP_Lantern_LargeShip_BrigDeck_StairsRight_C : ABP_InteractableShipLantern_C {

	void UserConstructionScript(); // Function BP_Lantern_LargeShip_BrigDeck_StairsRight.BP_Lantern_LargeShip_BrigDeck_StairsRight_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

