// BlueprintGeneratedClass BP_FishingFish_Islehopper_03_Colour_05_Amethyst.BP_FishingFish_Islehopper_03_Colour_05_Amethyst_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Islehopper_03_Colour_05_Amethyst_C : ABP_FishingFish_Islehopper_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_Islehopper_03_Colour_05_Amethyst.BP_FishingFish_Islehopper_03_Colour_05_Amethyst_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

