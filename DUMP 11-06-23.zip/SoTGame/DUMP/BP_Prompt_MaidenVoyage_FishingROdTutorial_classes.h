// BlueprintGeneratedClass BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C
// Size: 0x6e8 (Inherited: 0x138)
struct UBP_Prompt_MaidenVoyage_FishingRodTutorial_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_RodWielded; // 0x140(0x01)
	bool State_FishBattling; // 0x141(0x01)
	bool State_CastRod; // 0x142(0x01)
	bool State_CaughtFish; // 0x143(0x01)
	bool State_DockWithCannon; // 0x144(0x01)
	bool State_BattleFish; // 0x145(0x01)
	bool State_FishTired; // 0x146(0x01)
	bool State_ReelingWhileBattling; // 0x147(0x01)
	struct FPrioritisedPromptWithHandle Prompt_CastRod; // 0x148(0x68)
	struct FPrioritisedPromptWithHandle Prompt_WaitForBite; // 0x1b0(0x68)
	struct FPrioritisedPromptWithHandle Prompt_BattleFish; // 0x218(0x68)
	struct FPrioritisedPromptWithHandle Prompt_ReelFish; // 0x280(0x68)
	struct FObjectMessagingHandle Handle_WieldRod; // 0x2e8(0x58)
	struct FObjectMessagingHandle Handle_CastRod; // 0x340(0x58)
	struct FObjectMessagingHandle Handle_FishBite; // 0x398(0x58)
	struct FObjectMessagingHandle Handle_FishCaught; // 0x3f0(0x58)
	struct FObjectMessagingHandle Handle_BattleFish; // 0x448(0x58)
	struct UClass* RequiredInput; // 0x4a0(0x08)
	struct UClass* WieldedItemType; // 0x4a8(0x08)
	struct UClass* Sword_WieldedItemType; // 0x4b0(0x08)
	struct FPrioritisedPromptWithHandle Prompt_SnapLine; // 0x4b8(0x68)
	struct FObjectMessagingHandle Handle_ReelingWhileBattling; // 0x520(0x58)
	struct FObjectMessagingHandle Handle_StowRod; // 0x578(0x58)
	bool FishStartedBattling; // 0x5d0(0x01)
	char UnknownData_5D1[0x7]; // 0x5d1(0x07)
	struct FObjectMessagingHandle Handle_FishEscaped; // 0x5d8(0x58)
	bool State_Completed; // 0x630(0x01)
	char UnknownData_631[0x7]; // 0x631(0x07)
	struct FObjectMessagingHandle Handle_PlayerDeath; // 0x638(0x58)
	struct FObjectMessagingHandle Handle_DockToObject; // 0x690(0x58)

	void FullStateReset(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.FullStateReset // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishEscapingFunc(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishEscapingFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnBattleWhilstReelingFunc(struct FEventFishingReelingWhileBattlingStateChange EventFishingReelingWhileBattlingStateChange); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnBattleWhilstReelingFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishCaughtFunc(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishCaughtFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishTiredFunc(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishTiredFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishBiteFunc(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishBiteFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCastRodFunc(struct FEventSetFishingAnimationState EventSetFishingAnimationState); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnCastRodFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnStowFunc(struct FEventStartStow EventStartStow); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnStowFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnWieldFunc(struct FEventObjectWielded EventObjectWielded); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnWieldFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ResetPromptState(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.ResetPromptState // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void PostInitialize(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.PostInitialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void OnWield(struct FEventObjectWielded Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnWield // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishTired(struct FEventFishingFishBecameTired Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishTired // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCastRod(struct FEventSetFishingAnimationState Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnCastRod // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishCaught(struct FEventFishingFishCaught Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishCaught // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishBite(struct FEventFishingFishStartedBattling Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishBite // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnBattleWhilstReeling(struct FEventFishingReelingWhileBattlingStateChange Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnBattleWhilstReeling // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnStow(struct FEventStartStow Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnStow // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnFishEscaping(struct FEventFishingFishEscaping Event); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnFishEscaping // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnTakeControl(struct FEventPlayerTakenControlOfControllable NewParam); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.OnTakeControl // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_MaidenVoyage_FishingRodTutorial(int32_t EntryPoint); // Function BP_Prompt_MaidenVoyage_FishingROdTutorial.BP_Prompt_MaidenVoyage_FishingRodTutorial_C.ExecuteUbergraph_BP_Prompt_MaidenVoyage_FishingRodTutorial // HasDefaults // @ game+0x18275d0
};

