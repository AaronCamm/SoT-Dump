// BlueprintGeneratedClass BP_FishingFish_AncientScale_03_Colour_01_Almond.BP_FishingFish_AncientScale_03_Colour_01_Almond_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_AncientScale_03_Colour_01_Almond_C : ABP_FishingFish_AncientScale_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_AncientScale_03_Colour_01_Almond.BP_FishingFish_AncientScale_03_Colour_01_Almond_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

