// BlueprintGeneratedClass BP_CosmeticOar.BP_CosmeticOar_C
// Size: 0x3d8 (Inherited: 0x3c8)
struct ABP_CosmeticOar_C : AActor {
	struct UStaticMeshComponent* Oar; // 0x3c8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)

	void UserConstructionScript(); // Function BP_CosmeticOar.BP_CosmeticOar_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

