// ScriptStruct AthenaAudio.AnimNotify_SoundSwitch
// Size: 0x18 (Inherited: 0x00)
struct FAnimNotify_SoundSwitch {
	struct FStringAssetReference SkeletalMeshReference; // 0x00(0x10)
	struct FName SkeletalMeshCategoryName; // 0x10(0x08)
};

// ScriptStruct AthenaAudio.StoryDrivenAudioPortalSetting
// Size: 0x18 (Inherited: 0x00)
struct FStoryDrivenAudioPortalSetting {
	struct FStoryFlag Story; // 0x00(0x08)
	struct UAudioSpaceDataAsset* AudioInsideSpace; // 0x08(0x08)
	struct UAudioSpaceDataAsset* AudioOutsideSpace; // 0x10(0x08)
};

