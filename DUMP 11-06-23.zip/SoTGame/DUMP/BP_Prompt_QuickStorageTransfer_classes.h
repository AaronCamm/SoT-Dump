// BlueprintGeneratedClass BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C
// Size: 0x278 (Inherited: 0x138)
struct UBP_Prompt_QuickStorageTransfer_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_Complete; // 0x140(0x01)
	bool State_ShowPrompt; // 0x141(0x01)
	char UnknownData_142[0x6]; // 0x142(0x06)
	struct FPrioritisedPromptWithHandle Prompt_QuickStorageTransfer_Take; // 0x148(0x68)
	struct FPrioritisedPromptWithHandle Prompt_QuickStorageTransfer_Add; // 0x1b0(0x68)
	bool State_ShowAdd; // 0x218(0x01)
	char UnknownData_219[0x7]; // 0x219(0x07)
	struct FObjectMessagingHandle Handle_ObjectWielded; // 0x220(0x58)

	void IsStorageContainer(TScriptInterface<struct UWieldableInterface> Object, bool Result); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.IsStorageContainer // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x18275d0
	struct FPromptEvaluation GetShowPrompt(); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.GetShowPrompt // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x18275d0
	struct FPromptEvaluation EvaluatePromptDisplayState(); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.EvaluatePromptDisplayState // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void OnObjectWielded(struct FEventObjectWielded Event); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.OnObjectWielded // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_QuickStorageTransfer(int32_t EntryPoint); // Function BP_Prompt_QuickStorageTransfer.BP_Prompt_QuickStorageTransfer_C.ExecuteUbergraph_BP_Prompt_QuickStorageTransfer // HasDefaults // @ game+0x18275d0
};

