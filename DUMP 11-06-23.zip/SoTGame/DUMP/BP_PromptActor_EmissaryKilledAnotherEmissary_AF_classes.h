// BlueprintGeneratedClass BP_PromptActor_EmissaryKilledAnotherEmissary_AF.BP_PromptActor_EmissaryKilledAnotherEmissary_AF_C
// Size: 0x450 (Inherited: 0x400)
struct ABP_PromptActor_EmissaryKilledAnotherEmissary_AF_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_Prompt_EmissaryKilledAnotherEmissary_C* PromptCoordinator; // 0x408(0x08)
	struct UClass* PromptCounterAccessKey; // 0x410(0x08)
	struct UClass* Company; // 0x418(0x08)
	struct TArray<struct FPrioritisedPromptWithHandle> Prompts; // 0x420(0x10)
	struct TArray<struct FName> ExpectedVictimCompanyName; // 0x430(0x10)
	struct TArray<struct UClass*> ExpectedVictimCompanies; // 0x440(0x10)

	void UserConstructionScript(); // Function BP_PromptActor_EmissaryKilledAnotherEmissary_AF.BP_PromptActor_EmissaryKilledAnotherEmissary_AF_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_PromptActor_EmissaryKilledAnotherEmissary_AF.BP_PromptActor_EmissaryKilledAnotherEmissary_AF_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_PromptActor_EmissaryKilledAnotherEmissary_AF.BP_PromptActor_EmissaryKilledAnotherEmissary_AF_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptActor_EmissaryKilledAnotherEmissary_AF(int32_t EntryPoint); // Function BP_PromptActor_EmissaryKilledAnotherEmissary_AF.BP_PromptActor_EmissaryKilledAnotherEmissary_AF_C.ExecuteUbergraph_BP_PromptActor_EmissaryKilledAnotherEmissary_AF //  // @ game+0x18275d0
};

