// BlueprintGeneratedClass BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C
// Size: 0x1e0 (Inherited: 0x138)
struct UBP_Prompt_EmissaryLevelRankChange_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_EmissaryRankChange; // 0x140(0x58)
	struct FName CompanyName; // 0x198(0x08)
	int32_t NewLevel; // 0x1a0(0x04)
	bool SurfacedThisSession; // 0x1a4(0x01)
	char UnknownData_1A5[0x3]; // 0x1a5(0x03)
	struct FName ExpectedCompanyName; // 0x1a8(0x08)
	int32_t ExpectedLevel; // 0x1b0(0x04)
	char UnknownData_1B4[0x4]; // 0x1b4(0x04)
	struct TArray<struct FPrioritisedPromptWithHandle> Prompts; // 0x1b8(0x10)
	struct UClass* PromptAccessKey; // 0x1c8(0x08)
	int32_t PromptIndex; // 0x1d0(0x04)
	int32_t NumberOfPrompts; // 0x1d4(0x04)
	float InitialDelay; // 0x1d8(0x04)
	float ShowPromptDuration; // 0x1dc(0x04)

	void OnEmissaryLevelRankChange(struct FEmissaryLevelRankChange NewParam); // Function BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C.OnEmissaryLevelRankChange // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void EmissaryLevelRankChange(struct FEmissaryLevelRankChange NewParam); // Function BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C.EmissaryLevelRankChange // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_EmissaryLevelRankChange(int32_t EntryPoint); // Function BP_Prompt_EmissaryLevelRankChange.BP_Prompt_EmissaryLevelRankChange_C.ExecuteUbergraph_BP_Prompt_EmissaryLevelRankChange // HasDefaults // @ game+0x18275d0
};

