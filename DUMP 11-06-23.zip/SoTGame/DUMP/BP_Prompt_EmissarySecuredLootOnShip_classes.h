// BlueprintGeneratedClass BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C
// Size: 0x1d8 (Inherited: 0x138)
struct UBP_Prompt_EmissarySecuredLootOnShip_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_EmissarySecuredLootOnShip; // 0x140(0x58)
	struct FName CompanyName; // 0x198(0x08)
	bool SurfacedThisSession; // 0x1a0(0x01)
	char UnknownData_1A1[0x3]; // 0x1a1(0x03)
	struct FName ExpectedCompanyName; // 0x1a4(0x08)
	char UnknownData_1AC[0x4]; // 0x1ac(0x04)
	struct TArray<struct FPrioritisedPromptWithHandle> Prompts; // 0x1b0(0x10)
	struct UClass* PromptAccessKey; // 0x1c0(0x08)
	int32_t PromptIndex; // 0x1c8(0x04)
	int32_t NumberOfPrompts; // 0x1cc(0x04)
	float InitialDelay; // 0x1d0(0x04)
	float ShowPromptDuration; // 0x1d4(0x04)

	void OnEmissarySecuredLootOnShip(struct FEmissarySecuredLootOnShipNetworkEvent NewParam); // Function BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C.OnEmissarySecuredLootOnShip // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void EmissarySecuredLootOnShip(struct FEmissarySecuredLootOnShipNetworkEvent NewParam); // Function BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C.EmissarySecuredLootOnShip // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_EmissarySecuredLootOnShip(int32_t EntryPoint); // Function BP_Prompt_EmissarySecuredLootOnShip.BP_Prompt_EmissarySecuredLootOnShip_C.ExecuteUbergraph_BP_Prompt_EmissarySecuredLootOnShip // HasDefaults // @ game+0x18275d0
};

