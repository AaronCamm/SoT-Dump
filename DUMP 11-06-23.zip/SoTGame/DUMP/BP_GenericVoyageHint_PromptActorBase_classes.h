// BlueprintGeneratedClass BP_GenericVoyageHint_PromptActorBase.BP_GenericVoyageHint_PromptActorBase_C
// Size: 0x419 (Inherited: 0x400)
struct ABP_GenericVoyageHint_PromptActorBase_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_GenericVoyageHintPromptCoordinator_Base_C* PromptCoordinator; // 0x408(0x08)
	struct UClass* PromptAccessKey; // 0x410(0x08)
	char HintType; // 0x418(0x01)

	void UserConstructionScript(); // Function BP_GenericVoyageHint_PromptActorBase.BP_GenericVoyageHint_PromptActorBase_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_GenericVoyageHint_PromptActorBase.BP_GenericVoyageHint_PromptActorBase_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_GenericVoyageHint_PromptActorBase.BP_GenericVoyageHint_PromptActorBase_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_GenericVoyageHint_PromptActorBase(int32_t EntryPoint); // Function BP_GenericVoyageHint_PromptActorBase.BP_GenericVoyageHint_PromptActorBase_C.ExecuteUbergraph_BP_GenericVoyageHint_PromptActorBase //  // @ game+0x18275d0
};

