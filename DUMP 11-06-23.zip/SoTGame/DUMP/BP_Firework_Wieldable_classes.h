// BlueprintGeneratedClass BP_Firework_Wieldable.BP_Firework_Wieldable_C
// Size: 0x808 (Inherited: 0x7e0)
struct ABP_Firework_Wieldable_C : AStaticMeshWieldableItem {
	struct UUsableWieldableComponent* UsableWieldable; // 0x7e0(0x08)
	struct UWieldableInteractableComponent* WieldableInteractable; // 0x7e8(0x08)
	struct UPickupableComponent* Pickupable; // 0x7f0(0x08)
	struct UConsumableWieldableComponent* ConsumableWieldable; // 0x7f8(0x08)
	struct UInventoryItemComponent* InventoryItem; // 0x800(0x08)

	void UserConstructionScript(); // Function BP_Firework_Wieldable.BP_Firework_Wieldable_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

