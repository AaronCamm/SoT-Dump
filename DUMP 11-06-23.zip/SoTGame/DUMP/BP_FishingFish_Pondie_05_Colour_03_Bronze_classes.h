// BlueprintGeneratedClass BP_FishingFish_Pondie_05_Colour_03_Bronze.BP_FishingFish_Pondie_05_Colour_03_Bronze_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Pondie_05_Colour_03_Bronze_C : ABP_FishingFish_Pondie_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_Pondie_05_Colour_03_Bronze.BP_FishingFish_Pondie_05_Colour_03_Bronze_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

