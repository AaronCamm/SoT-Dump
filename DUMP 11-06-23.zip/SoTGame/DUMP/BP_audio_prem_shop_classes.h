// BlueprintGeneratedClass BP_audio_prem_shop.BP_audio_prem_shop_C
// Size: 0x3f0 (Inherited: 0x3c8)
struct ABP_audio_prem_shop_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3c8(0x08)
	struct UAudioPortalComponent* AudioPortal; // 0x3d0(0x08)
	struct UWwiseEmitterComponent* WwiseEmitter1; // 0x3d8(0x08)
	struct UAudioSpaceComponent* AudioSpace; // 0x3e0(0x08)
	struct USceneComponent* Scene; // 0x3e8(0x08)

	void UserConstructionScript(); // Function BP_audio_prem_shop.BP_audio_prem_shop_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_audio_prem_shop.BP_audio_prem_shop_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_audio_prem_shop(int32_t EntryPoint); // Function BP_audio_prem_shop.BP_audio_prem_shop_C.ExecuteUbergraph_BP_audio_prem_shop //  // @ game+0x18275d0
};

