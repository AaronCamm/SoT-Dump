// BlueprintGeneratedClass BP_ShipStorageBarrel.BP_ShipStorageBarrel_C
// Size: 0x3d8 (Inherited: 0x3c8)
struct ABP_ShipStorageBarrel_C : AActor {
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x3c8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x3d0(0x08)

	void UserConstructionScript(); // Function BP_ShipStorageBarrel.BP_ShipStorageBarrel_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

