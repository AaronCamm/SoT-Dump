// BlueprintGeneratedClass BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C
// Size: 0x2ba (Inherited: 0x138)
struct UBP_Prompt_Sitting_ThirdPerson_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_LocalPlayerEnteredSittingState; // 0x140(0x58)
	struct FPrioritisedPromptWithHandle Prompt_ThirdPerson; // 0x198(0x68)
	float PromptDisplayDuration; // 0x200(0x04)
	bool CrewInRadius; // 0x204(0x01)
	bool PromptOnCooldown; // 0x205(0x01)
	char UnknownData_206[0x2]; // 0x206(0x02)
	struct FObjectMessagingHandle Handle_LocalPlayerExitedSittingState; // 0x208(0x58)
	struct FObjectMessagingHandle Handle_LocalPlayerEnteredSittingThirdPersonCameraState; // 0x260(0x58)
	bool PlayerOnSeat; // 0x2b8(0x01)
	bool PromptEvaluated; // 0x2b9(0x01)

	void Evaluate(); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void LocalPlayerEnteredSittingState(struct FEventLocalPlayerEnteredSittingState Event); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.LocalPlayerEnteredSittingState // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void LocalPlayerExitedSittingState(struct FEventLocalPlayerExittedSittingState Event); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.LocalPlayerExitedSittingState // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void LocalPlayerEnteredSittingThirdPersonCamera(struct FEventLocalPlayerEnteredSittingThirdPersonCameraState Event); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.LocalPlayerEnteredSittingThirdPersonCamera // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_Sitting_ThirdPerson(int32_t EntryPoint); // Function BP_Prompt_Sitting_ThirdPerson.BP_Prompt_Sitting_ThirdPerson_C.ExecuteUbergraph_BP_Prompt_Sitting_ThirdPerson // HasDefaults // @ game+0x18275d0
};

