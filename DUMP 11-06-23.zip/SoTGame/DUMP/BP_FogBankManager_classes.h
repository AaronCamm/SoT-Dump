// BlueprintGeneratedClass BP_FogBankManager.BP_FogBankManager_C
// Size: 0x3f0 (Inherited: 0x3e8)
struct ABP_FogBankManager_C : AFogBankManager {
	struct USceneComponent* DefaultSceneRoot; // 0x3e8(0x08)

	void UserConstructionScript(); // Function BP_FogBankManager.BP_FogBankManager_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

