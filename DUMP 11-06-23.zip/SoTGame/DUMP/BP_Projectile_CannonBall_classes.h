// BlueprintGeneratedClass BP_Projectile_CannonBall.BP_Projectile_CannonBall_C
// Size: 0x668 (Inherited: 0x650)
struct ABP_Projectile_CannonBall_C : ACannonProjectile {
	struct USphereCollisionExtentAdjustOverTimeComponent* SphereCollisionExtentAdjustOverTime; // 0x650(0x08)
	struct UStaticMeshComponent* CannonBall; // 0x658(0x08)
	struct USphereComponent* Collision; // 0x660(0x08)

	void UserConstructionScript(); // Function BP_Projectile_CannonBall.BP_Projectile_CannonBall_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

