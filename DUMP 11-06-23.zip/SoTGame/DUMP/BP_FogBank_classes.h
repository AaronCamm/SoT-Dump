// BlueprintGeneratedClass BP_FogBank.BP_FogBank_C
// Size: 0x598 (Inherited: 0x590)
struct ABP_FogBank_C : AFogBank {
	struct UAthenaPlayerZonePenetrationTrackerComponent* AthenaPlayerZonePenetrationTracker; // 0x590(0x08)

	void UserConstructionScript(); // Function BP_FogBank.BP_FogBank_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

