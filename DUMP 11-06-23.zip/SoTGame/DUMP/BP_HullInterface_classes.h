// BlueprintGeneratedClass BP_HullInterface.BP_HullInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_HullInterface_C : UInterface {

	void Apply Hit(struct FVector HitPosition, struct FVector HitNormal, bool Has Decal, struct UDecalComponent* Decal); // Function BP_HullInterface.BP_HullInterface_C.Apply Hit // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

