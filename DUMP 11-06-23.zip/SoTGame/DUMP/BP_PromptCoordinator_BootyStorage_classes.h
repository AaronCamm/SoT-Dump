// BlueprintGeneratedClass BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C
// Size: 0x490 (Inherited: 0x138)
struct UBP_PromptCoordinator_BootyStorage_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool ShowLootPrompt; // 0x140(0x01)
	bool ShowMermaidPrompt; // 0x141(0x01)
	bool HasUsedStatue; // 0x142(0x01)
	bool HasRetrievedLoot; // 0x143(0x01)
	char UnknownData_144[0x4]; // 0x144(0x04)
	struct FPrioritisedPromptWithHandle MermaidPrompt; // 0x148(0x68)
	struct FPrioritisedPromptWithHandle LootPrompt; // 0x1b0(0x68)
	struct FObjectMessagingHandle CrewStorageChangedHandle; // 0x218(0x58)
	struct FObjectMessagingHandle CrewStorageFullHandle; // 0x270(0x58)
	struct FObjectMessagingHandle ItemsRetrievedHandle; // 0x2c8(0x58)
	struct FObjectMessagingHandle RetrieveActorHandle; // 0x320(0x58)
	struct FObjectMessagingHandle WieldedEventHandle; // 0x378(0x58)
	struct UClass* PromptKey; // 0x3d0(0x08)
	struct AWieldableItem* CurrentlyWieldedItem; // 0x3d8(0x08)
	struct FObjectMessagingHandle StowedEventHandle; // 0x3e0(0x58)
	struct FObjectMessagingHandle RetrieveActorDespawnHandle; // 0x438(0x58)

	void OnBootyRetrieveActorDespawned(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnBootyRetrieveActorDespawned // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnStowedFunc(struct FEventObjectStowed Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnStowedFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnBootyRetrieveActorSpawned(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnBootyRetrieveActorSpawned // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void CrewHasLootToRetrieve(bool HasTreasure); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.CrewHasLootToRetrieve // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x18275d0
	void IsInSunkenKingdom(bool InSunkenKingdom); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.IsInSunkenKingdom // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x18275d0
	void Reset(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.Reset // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCrewStorageUpdateFunc(struct FEventOnCrewStorageUpdate Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnCrewStorageUpdateFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCrewStorageFullFunc(struct FEventOnCrewStorageFull Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnCrewStorageFullFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnWieldedFunc(struct FEventObjectWielded Object); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnWieldedFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void PostInitialize(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.PostInitialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void Uninitialize_Implementable(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.Uninitialize_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void SetPromptComplete(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.SetPromptComplete // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ResetLootPrompt(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.ResetLootPrompt // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ResetMermaidPrompt(); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.ResetMermaidPrompt // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnStowed(struct FEventObjectStowed Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnStowed // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnWielded(struct FEventObjectWielded Object); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnWielded // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCrewStorageChange_Event(struct FEventOnCrewStorageFull Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnCrewStorageChange_Event // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCrewStorageFull_Event(struct FEventOnCrewStorageUpdate Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnCrewStorageFull_Event // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnItemsRetrieved_Event(struct FEventItemsRetrieved Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnItemsRetrieved_Event // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnBootyActorDespawned_Event(struct FRetrieveBootyActorDespawnedEvent Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnBootyActorDespawned_Event // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnBootyActorSpawned_Event(struct FRetrieveBootyActorSpawnedEvent Event); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.OnBootyActorSpawned_Event // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptCoordinator_BootyStorage(int32_t EntryPoint); // Function BP_PromptCoordinator_BootyStorage.BP_PromptCoordinator_BootyStorage_C.ExecuteUbergraph_BP_PromptCoordinator_BootyStorage // HasDefaults // @ game+0x18275d0
};

