// BlueprintGeneratedClass BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C
// Size: 0x270 (Inherited: 0x138)
struct UBP_Prompt_RepairShipCapstan_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_CapstanDamaged; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct FObjectMessagingHandle Handle_OnCapstanDamaged; // 0x148(0x58)
	bool State_Complete; // 0x1a0(0x01)
	char UnknownData_1A1[0x7]; // 0x1a1(0x07)
	struct FPrioritisedPromptWithHandle Prompt_RepairShip; // 0x1a8(0x68)
	struct FObjectMessagingHandle Handle_CurrentShipChanged; // 0x210(0x58)
	struct AShip* CurrentShip; // 0x268(0x08)

	void UnregisterDamageEventFromCurrentShip(); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.UnregisterDamageEventFromCurrentShip // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterDamageEventWithCurrentShip(); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.RegisterDamageEventWithCurrentShip // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void OnCurrentShipChanged(struct FEventCurrentShipChanged Event); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.OnCurrentShipChanged // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnShipDamaged(struct FEventCapstanDamageLevelChanged Event); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.OnShipDamaged // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_RepairShipCapstan(int32_t EntryPoint); // Function BP_Prompt_RepairShipCapstan.BP_Prompt_RepairShipCapstan_C.ExecuteUbergraph_BP_Prompt_RepairShipCapstan // HasDefaults // @ game+0x18275d0
};

