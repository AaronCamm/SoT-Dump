// BlueprintGeneratedClass BP_FirePropagationActor_LargeShip.BP_FirePropagationActor_LargeShip_C
// Size: 0x3d8 (Inherited: 0x3c8)
struct ABP_FirePropagationActor_LargeShip_C : AActor {
	struct UShipFirePropagationComponent* ShipFirePropagation; // 0x3c8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)

	void UserConstructionScript(); // Function BP_FirePropagationActor_LargeShip.BP_FirePropagationActor_LargeShip_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

