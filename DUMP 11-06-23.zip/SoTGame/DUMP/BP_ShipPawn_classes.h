// BlueprintGeneratedClass BP_ShipPawn.BP_ShipPawn_C
// Size: 0x480 (Inherited: 0x478)
struct ABP_ShipPawn_C : AShipProxyPawn {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function BP_ShipPawn.BP_ShipPawn_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

