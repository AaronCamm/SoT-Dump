// BlueprintGeneratedClass BP_FishingFish_StormFish_03_Colour_02_Shores.BP_FishingFish_StormFish_03_Colour_02_Shores_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_StormFish_03_Colour_02_Shores_C : ABP_FishingFish_StormFish_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_StormFish_03_Colour_02_Shores.BP_FishingFish_StormFish_03_Colour_02_Shores_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

