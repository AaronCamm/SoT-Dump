// BlueprintGeneratedClass BP_FishingFish_StormFish_05_Colour_03_Wild.BP_FishingFish_StormFish_05_Colour_03_Wild_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_StormFish_05_Colour_03_Wild_C : ABP_FishingFish_StormFish_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_StormFish_05_Colour_03_Wild.BP_FishingFish_StormFish_05_Colour_03_Wild_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

