// Class AuthenticationToken.JwtAuthenticationTokenSettings
// Size: 0x38 (Inherited: 0x28)
struct UJwtAuthenticationTokenSettings : UObject {
	struct FString TokenSecretKey; // 0x28(0x10)
};

// Class AuthenticationToken.JwtAuthenticationTokenEditorSettings
// Size: 0x38 (Inherited: 0x28)
struct UJwtAuthenticationTokenEditorSettings : UObject {
	struct FString TokenSecretKey; // 0x28(0x10)
};

