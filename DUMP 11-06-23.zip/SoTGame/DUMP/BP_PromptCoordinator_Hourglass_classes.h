// BlueprintGeneratedClass BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C
// Size: 0x269 (Inherited: 0x138)
struct UBP_PromptCoordinator_Hourglass_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle HandlePlayerApproachesHourglass; // 0x140(0x58)
	bool PlayerInRange; // 0x198(0x01)
	bool PromptEvaluated; // 0x199(0x01)
	char UnknownData_19A[0x2]; // 0x19a(0x02)
	float Prompt Delay; // 0x19c(0x04)
	struct FPrioritisedPromptWithHandle PromptHourglassTutorial1; // 0x1a0(0x68)
	float PromptDisplayDuration; // 0x208(0x04)
	char UnknownData_20C[0x4]; // 0x20c(0x04)
	struct FObjectMessagingHandle HandleChoseFaction; // 0x210(0x58)
	bool FactionChosen; // 0x268(0x01)

	void UnregisterOtherEvents_Implementable(); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void CustomEvent_1(struct FEventLocalPlayerApproachedHourglass Ev); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void CrewJoinedFaction(struct FCrewJoinedFaction Event); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.CrewJoinedFaction // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptCoordinator_Hourglass(int32_t EntryPoint); // Function BP_PromptCoordinator_Hourglass.BP_PromptCoordinator_Hourglass_C.ExecuteUbergraph_BP_PromptCoordinator_Hourglass // HasDefaults // @ game+0x18275d0
};

