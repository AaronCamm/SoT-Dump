// BlueprintGeneratedClass BP_FishingFish_Battlegill_03_Colour_01_Jade.BP_FishingFish_Battlegill_03_Colour_01_Jade_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Battlegill_03_Colour_01_Jade_C : ABP_FishingFish_Battlegill_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_Battlegill_03_Colour_01_Jade.BP_FishingFish_Battlegill_03_Colour_01_Jade_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

