// BlueprintGeneratedClass BP_DamageZoneInterface.BP_DamageZoneInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_DamageZoneInterface_C : UInterface {

	void GetNumExternalHits(int32_t NumExternalHits); // Function BP_DamageZoneInterface.BP_DamageZoneInterface_C.GetNumExternalHits // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ClearDecalFlags(); // Function BP_DamageZoneInterface.BP_DamageZoneInterface_C.ClearDecalFlags // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void AddExternalHit(struct FHullDamageHit Hit Data); // Function BP_DamageZoneInterface.BP_DamageZoneInterface_C.AddExternalHit // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

