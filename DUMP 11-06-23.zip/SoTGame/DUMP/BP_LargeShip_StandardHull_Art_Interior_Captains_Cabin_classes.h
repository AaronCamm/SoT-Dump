// BlueprintGeneratedClass BP_LargeShip_StandardHull_Art_Interior_Captains_Cabin.BP_LargeShip_StandardHull_Art_Interior_Captains_Cabin_C
// Size: 0x470 (Inherited: 0x3c8)
struct ABP_LargeShip_StandardHull_Art_Interior_Captains_Cabin_C : AActor {
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x3c8(0x08)
	struct UStaticMeshComponent* trs_candlestick_01_a; // 0x3d0(0x08)
	struct UStaticMeshComponent* cmn_candle_01_a; // 0x3d8(0x08)
	struct UStaticMeshComponent* cap_inkwell_01_a; // 0x3e0(0x08)
	struct UChildActorComponent* CaptainsBookcase; // 0x3e8(0x08)
	struct UChildActorComponent* BP_LargeShip_CapCabin_Dressing_01_a; // 0x3f0(0x08)
	struct UStaticMeshComponent* cap_cabinet_02_b; // 0x3f8(0x08)
	struct UStaticMeshComponent* cap_cage_01_b; // 0x400(0x08)
	struct UStaticMeshComponent* cap_cage_01_a; // 0x408(0x08)
	struct UParticleSystemComponent* vfx_tavern_candle_looping_01_a8; // 0x410(0x08)
	struct UParticleSystemComponent* vfx_tavern_candle_looping_01_a1; // 0x418(0x08)
	struct UStaticMeshComponent* gmp_pl_cabin_cabinet_a_01; // 0x420(0x08)
	struct UStaticMeshComponent* shp_item_shelf_01_a; // 0x428(0x08)
	struct UStaticMeshComponent* cap_cabin_drawer_01_a; // 0x430(0x08)
	struct UStaticMeshComponent* cap_cabin_trunk_01_a; // 0x438(0x08)
	struct UStaticMeshComponent* cap_cabin_trunk_01_a1; // 0x440(0x08)
	struct UMergedStaticMeshComponent* MergedStaticMesh_col; // 0x448(0x08)
	struct UStaticMeshComponent* cap_skull_candle_01_a; // 0x450(0x08)
	struct UStaticMeshComponent* cap_cabin_map_rolls_01_a; // 0x458(0x08)
	struct UMergedStaticMeshComponent* MergedStaticMesh; // 0x460(0x08)
	struct UStaticMeshComponent* shp_interior_captains_cabin_01_a; // 0x468(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_StandardHull_Art_Interior_Captains_Cabin.BP_LargeShip_StandardHull_Art_Interior_Captains_Cabin_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

