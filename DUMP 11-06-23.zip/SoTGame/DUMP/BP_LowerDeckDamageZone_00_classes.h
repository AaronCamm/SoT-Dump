// BlueprintGeneratedClass BP_LowerDeckDamageZone_00.BP_LowerDeckDamageZone_00_C
// Size: 0x8a0 (Inherited: 0x8a0)
struct ABP_LowerDeckDamageZone_00_C : ABP_BaseInternalDamageZone_C {

	void UserConstructionScript(); // Function BP_LowerDeckDamageZone_00.BP_LowerDeckDamageZone_00_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

