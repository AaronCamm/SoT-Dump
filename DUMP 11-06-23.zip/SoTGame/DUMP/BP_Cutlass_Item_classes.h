// BlueprintGeneratedClass BP_Cutlass_Item.BP_Cutlass_Item_C
// Size: 0xb48 (Inherited: 0xb40)
struct ABP_Cutlass_Item_C : APlayerMeleeWeapon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb40(0x08)

	void DoBlockEffect(); // Function BP_Cutlass_Item.BP_Cutlass_Item_C.DoBlockEffect // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_Cutlass_Item.BP_Cutlass_Item_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnBlockedAttack(struct FEventBlocked Event); // Function BP_Cutlass_Item.BP_Cutlass_Item_C.OnBlockedAttack // Event|Protected|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Cutlass_Item(int32_t EntryPoint); // Function BP_Cutlass_Item.BP_Cutlass_Item_C.ExecuteUbergraph_BP_Cutlass_Item //  // @ game+0x18275d0
};

