// BlueprintGeneratedClass BP_FishingFish_Battlegill_05_Colour_05_Bittersweet.BP_FishingFish_Battlegill_05_Colour_05_Bittersweet_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Battlegill_05_Colour_05_Bittersweet_C : ABP_FishingFish_Battlegill_05_C {

	void UserConstructionScript(); // Function BP_FishingFish_Battlegill_05_Colour_05_Bittersweet.BP_FishingFish_Battlegill_05_Colour_05_Bittersweet_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

