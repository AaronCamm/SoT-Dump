// BlueprintGeneratedClass BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C
// Size: 0x3fa (Inherited: 0x138)
struct UBP_Prompt_MaidenVoyage_RowboatTutorial_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_SatInRowboat; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct FPrioritisedPromptWithHandle Prompt_RowTheBoat; // 0x148(0x68)
	struct FObjectMessagingHandle Handle_UseRowboat; // 0x1b0(0x58)
	bool State_LeaveRowboat; // 0x208(0x01)
	char UnknownData_209[0x7]; // 0x209(0x07)
	struct FObjectMessagingHandle Handle_LeaveRowboat; // 0x210(0x58)
	struct FPrioritisedPromptWithHandle Prompt_ReleaseOars; // 0x268(0x68)
	struct FPrioritisedPromptWithHandle Prompt_Brake; // 0x2d0(0x68)
	struct FPrioritisedPromptWithHandle Prompt_OneAtATime; // 0x338(0x68)
	struct FObjectMessagingHandle Handle_StrokeEnded; // 0x3a0(0x58)
	bool State_StrokeCompleted; // 0x3f8(0x01)
	bool State_Completed; // 0x3f9(0x01)

	void OnStrokeEndedFunc(); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.OnStrokeEndedFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnLeaveRowboatFunc(); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.OnLeaveRowboatFunc // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnSitInRowboatFunc(struct FEventPlayerTakenControlOfControllable EventPlayerTakenControlOfControllable); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.OnSitInRowboatFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ResetState(); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.ResetState // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void PostInitialize(); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.PostInitialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void OnSitInRowboat(struct FEventPlayerTakenControlOfControllable Event); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.OnSitInRowboat // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnLeaveRowboat(struct FEventPlayerReliquishedControlOfControllable Event); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.OnLeaveRowboat // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnStrokeEnded(struct FEventOarStrokeEnded Event); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.OnStrokeEnded // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_MaidenVoyage_RowboatTutorial(int32_t EntryPoint); // Function BP_Prompt_MaidenVoyage_RowboatTutorial.BP_Prompt_MaidenVoyage_RowboatTutorial_C.ExecuteUbergraph_BP_Prompt_MaidenVoyage_RowboatTutorial // HasDefaults // @ game+0x18275d0
};

