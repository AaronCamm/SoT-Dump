// BlueprintGeneratedClass BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C
// Size: 0x218 (Inherited: 0x138)
struct UBP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_CrewEnteredTunnelOfTheDamnedPortalProximity; // 0x140(0x58)
	struct FPrioritisedPromptWithHandle Prompt_BootyWillBeLost; // 0x198(0x68)
	float PromptDisplayDuration; // 0x200(0x04)
	bool CrewInRadius; // 0x204(0x01)
	bool PromptOnCooldown; // 0x205(0x01)
	char UnknownData_206[0x2]; // 0x206(0x02)
	float PromptDisplayCooldown; // 0x208(0x04)
	char UnknownData_20C[0x4]; // 0x20c(0x04)
	struct UTunnelsOfTheDamnedLootFilterDataAsset* LootFilterDataAsset; // 0x210(0x08)

	void On Crew Entered Radius(struct FCrewEnteredTunnelOfTheDamnedPortalProximityEvent Event); // Function BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C.On Crew Entered Radius // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void Crew Entered Tunnel of The Damned Portal Proximity(struct FCrewEnteredTunnelOfTheDamnedPortalProximityEvent Event); // Function BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C.Crew Entered Tunnel of The Damned Portal Proximity // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_TunnelOfTheDamned_BootyWillBeLost(int32_t EntryPoint); // Function BP_Prompt_TunnelOfTheDamned_BootyWillBeLost.BP_Prompt_TunnelOfTheDamned_BootyWillBeLost_C.ExecuteUbergraph_BP_Prompt_TunnelOfTheDamned_BootyWillBeLost // HasDefaults // @ game+0x18275d0
};

