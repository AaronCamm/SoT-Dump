// BlueprintGeneratedClass BP_ShipVanityChest.BP_ShipVanityChest_C
// Size: 0x5a8 (Inherited: 0x5a0)
struct ABP_ShipVanityChest_C : APossessionsChest {
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x5a0(0x08)

	void UserConstructionScript(); // Function BP_ShipVanityChest.BP_ShipVanityChest_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

