// BlueprintGeneratedClass BP_FishingFish_Pondie_Base.BP_FishingFish_Pondie_Base_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Pondie_Base_C : ABP_FishingFish_Base_C {

	void UserConstructionScript(); // Function BP_FishingFish_Pondie_Base.BP_FishingFish_Pondie_Base_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

