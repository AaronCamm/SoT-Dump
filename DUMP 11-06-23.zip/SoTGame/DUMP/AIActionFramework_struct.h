// ScriptStruct AIActionFramework.RegionActionSpotContainer
// Size: 0x50 (Inherited: 0x00)
struct FRegionActionSpotContainer {
	struct TMap<struct UClass*, struct FActivityActionSpotContainer> RegisteredActionSpotsByActivity; // 0x00(0x50)
};

// ScriptStruct AIActionFramework.ActivityActionSpotContainer
// Size: 0x10 (Inherited: 0x00)
struct FActivityActionSpotContainer {
	char UnknownData_0[0x10]; // 0x00(0x10)
};

