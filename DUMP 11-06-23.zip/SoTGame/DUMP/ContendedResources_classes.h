// Class ContendedResources.ContendedResourceInfoInterface
// Size: 0x28 (Inherited: 0x28)
struct UContendedResourceInfoInterface : UInterface {
};

// Class ContendedResources.ContendedResourceServiceInterface
// Size: 0x28 (Inherited: 0x28)
struct UContendedResourceServiceInterface : UInterface {
};

// Class ContendedResources.ReservableContendedResourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UReservableContendedResourceInterface : UInterface {
};

// Class ContendedResources.ReservableContendedResourceStateInterface
// Size: 0x28 (Inherited: 0x28)
struct UReservableContendedResourceStateInterface : UInterface {
};

// Class ContendedResources.WorldResourceRegistryInterface
// Size: 0x28 (Inherited: 0x28)
struct UWorldResourceRegistryInterface : UInterface {
};

