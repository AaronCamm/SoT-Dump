// BlueprintGeneratedClass BP_PromptActor_ZoomableWieldableItem.BP_PromptActor_ZoomableWieldableItem_C
// Size: 0x418 (Inherited: 0x400)
struct ABP_PromptActor_ZoomableWieldableItem_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_Prompt_WieldableItemZoom_C* Coordinator; // 0x408(0x08)
	struct UClass* PromptClass; // 0x410(0x08)

	void UserConstructionScript(); // Function BP_PromptActor_ZoomableWieldableItem.BP_PromptActor_ZoomableWieldableItem_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_PromptActor_ZoomableWieldableItem.BP_PromptActor_ZoomableWieldableItem_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_PromptActor_ZoomableWieldableItem.BP_PromptActor_ZoomableWieldableItem_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptActor_ZoomableWieldableItem(int32_t EntryPoint); // Function BP_PromptActor_ZoomableWieldableItem.BP_PromptActor_ZoomableWieldableItem_C.ExecuteUbergraph_BP_PromptActor_ZoomableWieldableItem //  // @ game+0x18275d0
};

