// BlueprintGeneratedClass BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C
// Size: 0x210 (Inherited: 0x138)
struct UBP_Prompt_HuntersCallAtTheSovereign_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	bool State_ItemWielded; // 0x140(0x01)
	char UnknownData_141[0x7]; // 0x141(0x07)
	struct FObjectMessagingHandle Handle_OnWield; // 0x148(0x58)
	bool CaptainedSession; // 0x1a0(0x01)
	char UnknownData_1A1[0x7]; // 0x1a1(0x07)
	struct FPrioritisedPromptWithHandle Prompt; // 0x1a8(0x68)

	void OnItemWieldedFunc(struct FEventObjectWielded Object); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.OnItemWieldedFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void InitializeAndStart(struct AAthenaPlayerController* PlayerController); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.InitializeAndStart // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void OnWielded(struct FEventObjectWielded Object); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.OnWielded // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_HuntersCallAtTheSovereign(int32_t EntryPoint); // Function BP_Prompt_HuntersCallAtTheSovereign.BP_Prompt_HuntersCallAtTheSovereign_C.ExecuteUbergraph_BP_Prompt_HuntersCallAtTheSovereign // HasDefaults // @ game+0x18275d0
};

