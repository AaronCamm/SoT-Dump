// Class ContestMatchmaking.ContestMatchmakingFactionMapping
// Size: 0x38 (Inherited: 0x28)
struct UContestMatchmakingFactionMapping : UObject {
	struct TArray<struct FContestMatchmakingFactionMapEntry> Factions; // 0x28(0x10)
};

// Class ContestMatchmaking.ContestMatchmakingProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UContestMatchmakingProviderInterface : UInterface {
};

