// BlueprintGeneratedClass BP_MeatItemInfo.BP_MeatItemInfo_C
// Size: 0x578 (Inherited: 0x568)
struct ABP_MeatItemInfo_C : ARewardableItemInfo {
	struct UDeliverableRedirectionComponent* DeliverableRedirection; // 0x568(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x570(0x08)

	void UserConstructionScript(); // Function BP_MeatItemInfo.BP_MeatItemInfo_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

