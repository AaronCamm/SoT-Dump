// BlueprintGeneratedClass BP_MultiShipCookingPot.BP_MultiShipCookingPot_C
// Size: 0x5f0 (Inherited: 0x5e0)
struct ABP_MultiShipCookingPot_C : ABP_CookingPotBase_C {
	struct UHitRegSnapshotRedirectImpactToReplicatedMovementAttachParentComponent* HitRegSnapshotRedirectImpactToReplicatedMovementAttachParent; // 0x5e0(0x08)
	struct UCookerIgnitionComponent* CookerIgnition; // 0x5e8(0x08)

	void UserConstructionScript(); // Function BP_MultiShipCookingPot.BP_MultiShipCookingPot_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

