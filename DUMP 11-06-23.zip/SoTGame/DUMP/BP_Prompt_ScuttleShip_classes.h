// BlueprintGeneratedClass BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C
// Size: 0x2d5 (Inherited: 0x138)
struct UBP_Prompt_ScuttleShip_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_CharacterDeadEvent; // 0x140(0x58)
	struct FObjectMessagingHandle Handle_WaitingToSpawnEndedEvent; // 0x198(0x58)
	struct FPrioritisedPromptWithHandle Prompt_ArrivedOnFerry; // 0x1f0(0x68)
	struct FPrioritisedPromptWithHandle Prompt_SuggestScuttling; // 0x258(0x68)
	float SpawnKillTimeThreshold; // 0x2c0(0x04)
	int32_t RepeatDeathThreshold; // 0x2c4(0x04)
	struct FGameTime TimeOfLastPvPDeath; // 0x2c8(0x08)
	int32_t NumRecentDeaths; // 0x2d0(0x04)
	bool DiedEnough; // 0x2d4(0x01)

	void IsOnFerryOfTheDamned(bool IsOnFerryOfTheDamned); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.IsOnFerryOfTheDamned // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void IsDeathConsideredSpawnKill(bool SpawnKill, struct FGameTime TimeOfDeath); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.IsDeathConsideredSpawnKill // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void IsPvPDeath(struct FEventCharacterDead Event, bool PvPDeath); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.IsPvPDeath // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnCharacterDead(struct FEventCharacterDead Event); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.OnCharacterDead // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void OnCharacterDeadEvent(struct FEventCharacterDead Event); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.OnCharacterDeadEvent // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void OnWaitingToSpawnEndedEvent(struct FEventWaitingToSpawnActionStateEndedClient Event); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.OnWaitingToSpawnEndedEvent // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Start(); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.Start // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_ScuttleShip(int32_t EntryPoint); // Function BP_Prompt_ScuttleShip.BP_Prompt_ScuttleShip_C.ExecuteUbergraph_BP_Prompt_ScuttleShip // HasDefaults // @ game+0x18275d0
};

