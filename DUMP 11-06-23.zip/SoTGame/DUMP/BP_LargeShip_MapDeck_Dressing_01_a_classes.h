// BlueprintGeneratedClass BP_LargeShip_MapDeck_Dressing_01_a.BP_LargeShip_MapDeck_Dressing_01_a_C
// Size: 0x448 (Inherited: 0x3d8)
struct ABP_LargeShip_MapDeck_Dressing_01_a_C : ATrinketReplacementActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d8(0x08)
	struct UStaticMeshComponent* fod_rum_01_a; // 0x3e0(0x08)
	struct UStaticMeshComponent* cmn_bottle_01_a2; // 0x3e8(0x08)
	struct UStaticMeshComponent* cmn_bottle_01_a1; // 0x3f0(0x08)
	struct UStaticMeshComponent* cmn_bottle_01_a; // 0x3f8(0x08)
	struct UStaticMeshComponent* shp_fry_pan_01_a; // 0x400(0x08)
	struct UStaticMeshComponent* fod_rum_01_a1; // 0x408(0x08)
	struct UStaticMeshComponent* tls_tankard_01_b2; // 0x410(0x08)
	struct UStaticMeshComponent* tls_tankard_01_b; // 0x418(0x08)
	struct UStaticMeshComponent* ptn_pois_01_a; // 0x420(0x08)
	struct UStaticMeshComponent* ptn_cure_01_a2; // 0x428(0x08)
	struct UStaticMeshComponent* ptn_cure_01_a; // 0x430(0x08)
	struct UStaticMeshComponent* tls_tankard_01_b1; // 0x438(0x08)
	struct UMergedStaticMeshComponent* MergedStaticMesh; // 0x440(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_MapDeck_Dressing_01_a.BP_LargeShip_MapDeck_Dressing_01_a_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_LargeShip_MapDeck_Dressing_01_a.BP_LargeShip_MapDeck_Dressing_01_a_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_LargeShip_MapDeck_Dressing_01_a(int32_t EntryPoint); // Function BP_LargeShip_MapDeck_Dressing_01_a.BP_LargeShip_MapDeck_Dressing_01_a_C.ExecuteUbergraph_BP_LargeShip_MapDeck_Dressing_01_a //  // @ game+0x18275d0
};

