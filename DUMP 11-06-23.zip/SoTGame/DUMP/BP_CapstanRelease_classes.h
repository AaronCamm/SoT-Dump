// BlueprintGeneratedClass BP_CapstanRelease.BP_CapstanRelease_C
// Size: 0x4d0 (Inherited: 0x4c8)
struct ABP_CapstanRelease_C : ACapstanRelease {
	struct UInteractableComponent* Interactable; // 0x4c8(0x08)

	struct FVector GetClosestInteractionPoint(struct FVector ReferencePosition, float OutInteractionPointRadius); // Function BP_CapstanRelease.BP_CapstanRelease_C.GetClosestInteractionPoint // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_CapstanRelease.BP_CapstanRelease_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

