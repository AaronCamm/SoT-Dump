// BlueprintGeneratedClass BP_WheelInterface.BP_WheelInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_WheelInterface_C : UInterface {

	void Receive Animation State(struct FRotator WheelRotation, float WheelAnimationTime, char EWheel, float Direction, float WheelRate); // Function BP_WheelInterface.BP_WheelInterface_C.Receive Animation State // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

