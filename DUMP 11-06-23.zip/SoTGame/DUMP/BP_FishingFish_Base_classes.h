// BlueprintGeneratedClass BP_FishingFish_Base.BP_FishingFish_Base_C
// Size: 0x920 (Inherited: 0x910)
struct ABP_FishingFish_Base_C : AFishingFish {
	struct UBoxComponent* WaterInteractionOverlap; // 0x910(0x08)
	struct UMaterialManipulationComponent* MaterialManipulation; // 0x918(0x08)

	void UserConstructionScript(); // Function BP_FishingFish_Base.BP_FishingFish_Base_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

