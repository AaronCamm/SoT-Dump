// BlueprintGeneratedClass BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C
// Size: 0x288 (Inherited: 0x138)
struct UBP_Prompt_VisitSeapost_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_EventObjectWielded; // 0x140(0x58)
	struct FPrioritisedPromptWithHandle Prompt_WieledFishOrMeat; // 0x198(0x68)
	struct FPrioritisedPromptWithHandle Prompt_VisitSeapost; // 0x200(0x68)
	bool IsWieldingMeatOrFish; // 0x268(0x01)
	char UnknownData_269[0x3]; // 0x269(0x03)
	float DisplayDuration; // 0x26c(0x04)
	float DelayUntilNextPrompt; // 0x270(0x04)
	char UnknownData_274[0x4]; // 0x274(0x04)
	struct TArray<struct FNone*> IgnoredFood; // 0x278(0x10)

	void OnEventObjectWielded(struct FEventObjectWielded Event); // Function BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C.OnEventObjectWielded // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void EventObjectWielded(struct FEventObjectWielded Event); // Function BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C.EventObjectWielded // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_VisitSeapost(int32_t EntryPoint); // Function BP_Prompt_VisitSeapost.BP_Prompt_VisitSeapost_C.ExecuteUbergraph_BP_Prompt_VisitSeapost // HasDefaults // @ game+0x18275d0
};

