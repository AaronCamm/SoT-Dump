// BlueprintGeneratedClass BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C
// Size: 0x1f0 (Inherited: 0x138)
struct UBP_Prompt_EmissaryKilledAnotherEmissary_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle Handle_EmissaryKilledAnotherEmissary; // 0x140(0x58)
	struct FName CompanyName; // 0x198(0x08)
	struct FName VictimCompanyName; // 0x1a0(0x08)
	bool SurfacedThisSession; // 0x1a8(0x01)
	char UnknownData_1A9[0x3]; // 0x1a9(0x03)
	struct FName ExpectedCompanyName; // 0x1ac(0x08)
	char UnknownData_1B4[0x4]; // 0x1b4(0x04)
	struct TArray<struct FName> ExpectedVictimCompanyName; // 0x1b8(0x10)
	struct TArray<struct FPrioritisedPromptWithHandle> Prompts; // 0x1c8(0x10)
	struct UClass* PromptAccessKey; // 0x1d8(0x08)
	int32_t PromptIndex; // 0x1e0(0x04)
	int32_t NumberOfPrompts; // 0x1e4(0x04)
	float InitialDelay; // 0x1e8(0x04)
	float ShowPromptDuration; // 0x1ec(0x04)

	void OnEmissaryKilledAnotherEmissary(struct FEmissaryKilledAnotherEmissaryNetworkEvent NewParam); // Function BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C.OnEmissaryKilledAnotherEmissary // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void EmissaryKilledAnotherEmisary(struct FEmissaryKilledAnotherEmissaryNetworkEvent NewParam); // Function BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C.EmissaryKilledAnotherEmisary // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterOtherEvents_Implementable(); // Function BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C.RegisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_EmissaryKilledAnotherEmissary(int32_t EntryPoint); // Function BP_Prompt_EmissaryKilledAnotherEmissary.BP_Prompt_EmissaryKilledAnotherEmissary_C.ExecuteUbergraph_BP_Prompt_EmissaryKilledAnotherEmissary // HasDefaults // @ game+0x18275d0
};

