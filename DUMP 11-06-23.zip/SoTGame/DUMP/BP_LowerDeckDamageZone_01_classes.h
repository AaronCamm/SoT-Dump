// BlueprintGeneratedClass BP_LowerDeckDamageZone_01.BP_LowerDeckDamageZone_01_C
// Size: 0x8a0 (Inherited: 0x8a0)
struct ABP_LowerDeckDamageZone_01_C : ABP_BaseInternalDamageZone_C {

	void UserConstructionScript(); // Function BP_LowerDeckDamageZone_01.BP_LowerDeckDamageZone_01_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

