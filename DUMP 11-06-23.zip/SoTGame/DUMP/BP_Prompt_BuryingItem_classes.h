// BlueprintGeneratedClass BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C
// Size: 0x2e1 (Inherited: 0x138)
struct UBP_Prompt_BuryingItem_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle WieldableItemUseEvent; // 0x140(0x58)
	struct UClass* NotificationInputId; // 0x198(0x08)
	struct UClass* BuryingItemPromptAccessKey; // 0x1a0(0x08)
	struct FObjectMessagingHandle WieldableItemEquipEvent; // 0x1a8(0x58)
	struct FPrioritisedPromptWithHandle Prompt; // 0x200(0x68)
	bool WieldingShovel; // 0x268(0x01)
	char UnknownData_269[0x7]; // 0x269(0x07)
	struct FObjectMessagingHandle WieldableItemStow; // 0x270(0x58)
	struct UClass* In; // 0x2c8(0x08)
	bool UsingSecondaryInput; // 0x2d0(0x01)
	bool StatCompleted; // 0x2d1(0x01)
	char UnknownData_2D2[0x6]; // 0x2d2(0x06)
	struct FObjectMessagingDispatcherHandle CharacterDispatcher; // 0x2d8(0x08)
	bool HasShown; // 0x2e0(0x01)

	void OnWieldFunc(struct FEventObjectWielded EventObjectWielded); // Function BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C.OnWieldFunc // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void OnWieldEvent(struct FEventObjectWielded OnWieldEvent); // Function BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C.OnWieldEvent // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_BuryingItem(int32_t EntryPoint); // Function BP_Prompt_BuryingItem.BP_Prompt_BuryingItem_C.ExecuteUbergraph_BP_Prompt_BuryingItem // HasDefaults // @ game+0x18275d0
};

