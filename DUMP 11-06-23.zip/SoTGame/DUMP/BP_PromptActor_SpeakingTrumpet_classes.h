// BlueprintGeneratedClass BP_PromptActor_SpeakingTrumpet.BP_PromptActor_SpeakingTrumpet_C
// Size: 0x410 (Inherited: 0x400)
struct ABP_PromptActor_SpeakingTrumpet_C : ABP_PromptActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UBP_Prompt_SpeakingTrumpet_C* Coordinator; // 0x408(0x08)

	void UserConstructionScript(); // Function BP_PromptActor_SpeakingTrumpet.BP_PromptActor_SpeakingTrumpet_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void ReceiveBeginPlay(); // Function BP_PromptActor_SpeakingTrumpet.BP_PromptActor_SpeakingTrumpet_C.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ReceiveEndPlay(char EndPlayReason); // Function BP_PromptActor_SpeakingTrumpet.BP_PromptActor_SpeakingTrumpet_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_PromptActor_SpeakingTrumpet(int32_t EntryPoint); // Function BP_PromptActor_SpeakingTrumpet.BP_PromptActor_SpeakingTrumpet_C.ExecuteUbergraph_BP_PromptActor_SpeakingTrumpet //  // @ game+0x18275d0
};

