// BlueprintGeneratedClass BP_ShipFlagCustomizationChestInteraction.BP_ShipFlagCustomizationChestInteraction_C
// Size: 0x558 (Inherited: 0x550)
struct ABP_ShipFlagCustomizationChestInteraction_C : AShipFlagCustomizationChestInteraction {
	struct USceneComponent* DefaultSceneRoot; // 0x550(0x08)

	void UserConstructionScript(); // Function BP_ShipFlagCustomizationChestInteraction.BP_ShipFlagCustomizationChestInteraction_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

