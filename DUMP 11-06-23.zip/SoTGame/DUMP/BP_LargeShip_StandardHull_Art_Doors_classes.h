// BlueprintGeneratedClass BP_LargeShip_StandardHull_Art_Doors.BP_LargeShip_StandardHull_Art_Doors_C
// Size: 0x3e0 (Inherited: 0x3c8)
struct ABP_LargeShip_StandardHull_Art_Doors_C : AActor {
	struct UStaticMeshComponent* StaticMesh1; // 0x3c8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x3d0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_StandardHull_Art_Doors.BP_LargeShip_StandardHull_Art_Doors_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

