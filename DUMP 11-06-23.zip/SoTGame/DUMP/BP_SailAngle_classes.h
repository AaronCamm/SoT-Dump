// BlueprintGeneratedClass BP_SailAngle.BP_SailAngle_C
// Size: 0x870 (Inherited: 0x868)
struct ABP_SailAngle_C : ASailAngle {
	struct UInteractableComponent* Interactable; // 0x868(0x08)

	struct FDockableInfo GetDockableInfo(); // Function BP_SailAngle.BP_SailAngle_C.GetDockableInfo // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UserConstructionScript(); // Function BP_SailAngle.BP_SailAngle_C.UserConstructionScript // Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

