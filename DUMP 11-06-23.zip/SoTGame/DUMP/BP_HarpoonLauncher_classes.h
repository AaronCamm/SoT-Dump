// BlueprintGeneratedClass BP_HarpoonLauncher.BP_HarpoonLauncher_C
// Size: 0xcc8 (Inherited: 0xcb0)
struct ABP_HarpoonLauncher_C : AHarpoonLauncher {
	struct UStaticMeshComponent* CubeNotWalkable; // 0xcb0(0x08)
	struct UCapsuleComponent* MountCollision; // 0xcb8(0x08)
	struct UCapsuleComponent* BarrelCollision; // 0xcc0(0x08)

	void UserConstructionScript(); // Function BP_HarpoonLauncher.BP_HarpoonLauncher_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

