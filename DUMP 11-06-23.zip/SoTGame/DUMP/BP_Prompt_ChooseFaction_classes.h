// BlueprintGeneratedClass BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C
// Size: 0x352 (Inherited: 0x138)
struct UBP_Prompt_ChooseFaction_C : UBP_PromptCoordinator_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	struct FObjectMessagingHandle HandleChoseFaction; // 0x140(0x58)
	struct FPrioritisedPromptWithHandle PromptPirateLord1; // 0x198(0x68)
	struct FPrioritisedPromptWithHandle PromptFlameheart1; // 0x200(0x68)
	struct FPrioritisedPromptWithHandle PromptFlameheart2; // 0x268(0x68)
	struct FPrioritisedPromptWithHandle PromptPirateLord2; // 0x2d0(0x68)
	float PromptDelay; // 0x338(0x04)
	float PromptDisplayDuration; // 0x33c(0x04)
	bool FactionPromptFinished; // 0x340(0x01)
	bool FactionChosen; // 0x341(0x01)
	char UnknownData_342[0x6]; // 0x342(0x06)
	struct UClass* CurrentFaction; // 0x348(0x08)
	bool WarmapOpen; // 0x350(0x01)
	bool WarMapPromptFinished; // 0x351(0x01)

	void GetPrompt2FromCurrentFaction(struct FPrioritisedPromptWithHandle Prompt); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.GetPrompt2FromCurrentFaction // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void GetPrompt1FromCurrentFaction(struct FPrioritisedPromptWithHandle Prompt); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.GetPrompt1FromCurrentFaction // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void Evaluate(); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.Evaluate // Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterOtherEvents_Implementable(); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.UnregisterOtherEvents_Implementable // Event|Public|BlueprintEvent // @ game+0x18275d0
	void RegisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.RegisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void CrewJoinedFaction(struct FCrewJoinedFaction Event); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.CrewJoinedFaction // BlueprintCallable|BlueprintEvent // @ game+0x18275d0
	void UnregisterCharacterEvents_Implementable(struct FObjectMessagingDispatcherHandle CharacterDispatcher); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.UnregisterCharacterEvents_Implementable // Event|Public|HasOutParms|BlueprintEvent // @ game+0x18275d0
	void ExecuteUbergraph_BP_Prompt_ChooseFaction(int32_t EntryPoint); // Function BP_Prompt_ChooseFaction.BP_Prompt_ChooseFaction_C.ExecuteUbergraph_BP_Prompt_ChooseFaction // HasDefaults // @ game+0x18275d0
};

