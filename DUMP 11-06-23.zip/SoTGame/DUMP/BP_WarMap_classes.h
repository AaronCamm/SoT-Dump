// BlueprintGeneratedClass BP_WarMap.BP_WarMap_C
// Size: 0x9e8 (Inherited: 0x9d0)
struct ABP_WarMap_C : AWarMapProposalContainer {
	struct UChildActorComponent* VoteInteractionHardMode; // 0x9d0(0x08)
	struct UChildActorComponent* VoteInteractionNormalMode; // 0x9d8(0x08)
	struct UChildActorComponent* VoteInteractionSingle; // 0x9e0(0x08)

	void UserConstructionScript(); // Function BP_WarMap.BP_WarMap_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

