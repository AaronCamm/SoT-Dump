// BlueprintGeneratedClass BP_LargeShip_Capstan.BP_LargeShip_Capstan_C
// Size: 0x8e8 (Inherited: 0x8c8)
struct ABP_LargeShip_Capstan_C : ABP_Base_Capstan_C {
	struct UChildActorComponent* Arm1; // 0x8c8(0x08)
	struct UChildActorComponent* Arm4; // 0x8d0(0x08)
	struct UChildActorComponent* Arm3; // 0x8d8(0x08)
	struct UChildActorComponent* Arm2; // 0x8e0(0x08)

	void UserConstructionScript(); // Function BP_LargeShip_Capstan.BP_LargeShip_Capstan_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

