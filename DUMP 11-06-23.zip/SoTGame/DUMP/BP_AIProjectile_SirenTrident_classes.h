// BlueprintGeneratedClass BP_AIProjectile_SirenTrident.BP_AIProjectile_SirenTrident_C
// Size: 0x830 (Inherited: 0x818)
struct ABP_AIProjectile_SirenTrident_C : ASirenTridentProjectile {
	struct USphereCollisionExtentAdjustOverTimeComponent* SphereCollisionExtentAdjustOverTime; // 0x818(0x08)
	struct UStaticMeshComponent* Sphere; // 0x820(0x08)
	struct USphereComponent* Collision; // 0x828(0x08)

	void UserConstructionScript(); // Function BP_AIProjectile_SirenTrident.BP_AIProjectile_SirenTrident_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

