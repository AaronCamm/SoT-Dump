// BlueprintGeneratedClass BP_bld_pot_shop_boiler_01_a.BP_bld_pot_shop_boiler_01_a_C
// Size: 0x3e0 (Inherited: 0x3c8)
struct ABP_bld_pot_shop_boiler_01_a_C : AActor {
	struct UParticleSystemComponent* vfx_magic_fire_pot; // 0x3c8(0x08)
	struct UStaticMeshComponent* bld_pot_shop_boiler_01_a; // 0x3d0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)

	void UserConstructionScript(); // Function BP_bld_pot_shop_boiler_01_a.BP_bld_pot_shop_boiler_01_a_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

