// BlueprintGeneratedClass BP_VanityChestInteraction.BP_VanityChestInteraction_C
// Size: 0x700 (Inherited: 0x6f8)
struct ABP_VanityChestInteraction_C : AClothingChestInteraction {
	struct USceneComponent* DefaultSceneRoot; // 0x6f8(0x08)

	void UserConstructionScript(); // Function BP_VanityChestInteraction.BP_VanityChestInteraction_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

