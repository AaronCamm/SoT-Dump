// BlueprintGeneratedClass BP_FishingFish_Devilfish_03_Colour_02_Seashell.BP_FishingFish_Devilfish_03_Colour_02_Seashell_C
// Size: 0x920 (Inherited: 0x920)
struct ABP_FishingFish_Devilfish_03_Colour_02_Seashell_C : ABP_FishingFish_Devilfish_03_C {

	void UserConstructionScript(); // Function BP_FishingFish_Devilfish_03_Colour_02_Seashell.BP_FishingFish_Devilfish_03_Colour_02_Seashell_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x18275d0
};

